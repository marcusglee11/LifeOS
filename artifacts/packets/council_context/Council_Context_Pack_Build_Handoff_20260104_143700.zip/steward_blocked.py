#!/usr/bin/env python3
"""
steward_blocked.py - Report on BLOCKED packets visibility.

Scans artifacts/packets/blocked/*.yaml and emits a deterministic report
grouping by owner with age-hours and unblock_condition.
"""

import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import yaml

REPO_ROOT = Path(__file__).parent.parent.parent
BLOCKED_DIR = REPO_ROOT / "artifacts" / "packets" / "blocked"
REPORT_DIR = REPO_ROOT / "artifacts" / "packets" / "reports"


def parse_created_at(created_at: Optional[str]) -> Optional[datetime]:
    """Parse ISO 8601 timestamp."""
    if not created_at:
        return None
    try:
        # Handle various ISO formats
        if created_at.endswith('Z'):
            created_at = created_at[:-1] + '+00:00'
        return datetime.fromisoformat(created_at)
    except ValueError:
        return None


def calculate_age_hours(created_at: Optional[str]) -> str:
    """Calculate age in hours from created_at."""
    dt = parse_created_at(created_at)
    if not dt:
        return "UNKNOWN"
    
    now = datetime.now(timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    
    delta = now - dt
    hours = delta.total_seconds() / 3600
    return f"{hours:.1f}h"


def load_blocked_packets() -> list[dict]:
    """Load all BLOCKED packets from artifacts/packets/blocked/."""
    if not BLOCKED_DIR.exists():
        return []
    
    packets = []
    for path in sorted(BLOCKED_DIR.glob("*.yaml")):
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
            if data:
                data["_source_path"] = str(path.relative_to(REPO_ROOT))
                packets.append(data)
        except Exception as e:
            print(f"Warning: Failed to parse {path}: {e}", file=sys.stderr)
    
    return packets


def group_by_owner(packets: list[dict]) -> dict[str, list[dict]]:
    """Group packets by owner."""
    groups = {"Builder": [], "CEO": [], "Council": [], "UNKNOWN": []}
    
    for packet in packets:
        # Handle nested blocked structure
        blocked = packet.get("blocked", packet)
        owner = blocked.get("owner", "UNKNOWN")
        if owner not in groups:
            groups[owner] = []
        groups[owner].append(packet)
    
    return groups


def generate_report(groups: dict[str, list[dict]]) -> str:
    """Generate deterministic markdown report."""
    lines = [
        "# BLOCKED Items Report",
        "",
        f"**Generated**: {datetime.now(timezone.utc).isoformat()}",
        f"**Total Items**: {sum(len(v) for v in groups.values())}",
        "",
    ]
    
    for owner in ["Builder", "CEO", "Council", "UNKNOWN"]:
        items = groups.get(owner, [])
        if not items:
            continue
        
        lines.append(f"## Owner: {owner}")
        lines.append("")
        lines.append("| Source | Age | Unblock Condition |")
        lines.append("|--------|-----|-------------------|")
        
        for item in sorted(items, key=lambda x: x.get("_source_path", "")):
            blocked = item.get("blocked", item)
            source = item.get("_source_path", "UNKNOWN")
            created_at = blocked.get("created_at", item.get("created_at"))
            age = calculate_age_hours(created_at)
            condition = blocked.get("unblock_condition", "Not specified")
            lines.append(f"| {source} | {age} | {condition} |")
        
        lines.append("")
    
    return "\n".join(lines)


def main():
    packets = load_blocked_packets()
    
    if not packets:
        print("No blocked items found in artifacts/packets/blocked/")
        return 0
    
    groups = group_by_owner(packets)
    report = generate_report(groups)
    
    # Write report
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    report_path = REPORT_DIR / f"blocked_report_{ts}.md"
    report_path.write_text(report, encoding="utf-8")
    
    print(report)
    print(f"\nReport written to: {report_path}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
