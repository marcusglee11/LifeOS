#!/usr/bin/env python3
import sys
import yaml
import json
import argparse
import re
import os
import glob
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional, Set
from uuid import UUID

# Exit Codes
EXIT_PASS = 0
EXIT_FAIL_GENERIC = 1
EXIT_SCHEMA_VIOLATION = 2
EXIT_SECURITY_VIOLATION = 3
EXIT_LINEAGE_VIOLATION = 4
EXIT_REPLAY_VIOLATION = 5
EXIT_VERSION_INCOMPATIBLE = 6

# Constants
MAX_PAYLOAD_SIZE_KB = 8192
MAX_CLOCK_SKEW_SECONDS = 300
REQUIRED_SCHEMA_VERSION = "1.1"

# Taxonomy (MVP 9 + Deprecated)
CORE_PACKET_TYPES = {
    "COUNCIL_REVIEW_PACKET",
    "COUNCIL_APPROVAL_PACKET",
    "BUILD_PACKET",
    "REVIEW_PACKET",
    "HANDOFF_PACKET",
    "STATE_MANAGEMENT_PACKET",
    "CONTEXT_REQUEST_PACKET",
    "CONTEXT_RESPONSE_PACKET",
    "DOC_STEWARD_REQUEST_PACKET"
}

DEPRECATED_PACKET_TYPES = {
    "GATE_APPROVAL_PACKET",
    "FIX_PACKET",
    "ESCALATION_PACKET"
}

def fail(code: int, message: str):
    print(f"[FAIL] {message}", file=sys.stderr)
    sys.exit(code)

def parse_yaml_payload(content: str) -> Dict[str, Any]:
    try:
        return yaml.safe_load(content)
    except yaml.YAMLError as e:
        fail(EXIT_SCHEMA_VIOLATION, f"Invalid YAML format: {e}")

def extract_packet_data(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        fail(EXIT_FAIL_GENERIC, f"File not found: {path}")
    
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Size Check
    if len(content.encode('utf-8')) > MAX_PAYLOAD_SIZE_KB * 1024:
        fail(EXIT_SECURITY_VIOLATION, f"Payload size exceeds {MAX_PAYLOAD_SIZE_KB}KB limit")

    if path.endswith('.md'):
        match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
        if not match:
            fail(EXIT_SCHEMA_VIOLATION, "Markdown file missing YAML frontmatter")
        return parse_yaml_payload(match.group(1))
    else:
        return parse_yaml_payload(content)

def validate_uuid(val: Any, field: str):
    if not isinstance(val, str):
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' must be a string UUID")
    try:
        UUID(val)
    except ValueError:
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' is not a valid UUID: {val}")

def validate_timestamp(val: Any, field: str, ignore_skew: bool):
    if not isinstance(val, str):
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' must be a string ISO timestamp")
    try:
        dt = datetime.fromisoformat(val.replace('Z', '+00:00'))
        
        # Clock Skew Enforcement (P0.1)
        if not ignore_skew:
            now = datetime.now(timezone.utc)
            skew = abs((now - dt).total_seconds())
            if skew > MAX_CLOCK_SKEW_SECONDS:
                fail(EXIT_SECURITY_VIOLATION, f"Clock skew {skew}s exceeds max {MAX_CLOCK_SKEW_SECONDS}s")
    except ValueError:
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' invalid timestamp format: {val}")

def validate_ttl(data: Dict[str, Any]):
    # TTL Enforcement (P0.2)
    created_at = datetime.fromisoformat(data['created_at'].replace('Z', '+00:00'))
    ttl = data.get('ttl_hours', 72)
    
    if ttl == 0: return # Infinite
    
    if not isinstance(ttl, int):
        fail(EXIT_SCHEMA_VIOLATION, "ttl_hours must be integer")

    now = datetime.now(timezone.utc)
    age_hours = (now - created_at).total_seconds() / 3600
    if age_hours > ttl:
        fail(EXIT_SECURITY_VIOLATION, f"Packet TTL expired. Age: {age_hours:.2f}h > TTL: {ttl}h")

def validate_signature(data: Dict[str, Any]):
    # Signature Enforcement (P0.4)
    ptype = data['packet_type']
    is_draft = data.get('is_draft', False)
    sig_stub = data.get('signature_stub')

    required = False
    if ptype == "COUNCIL_APPROVAL_PACKET":
        required = True
    elif not is_draft:
        required = True
    
    if required and not sig_stub:
        fail(EXIT_SECURITY_VIOLATION, f"Signature stub required for {ptype} (is_draft={is_draft})")
    
    if sig_stub:
        if not isinstance(sig_stub, dict):
            fail(EXIT_SCHEMA_VIOLATION, "signature_stub must be object")
        if 'signer' not in sig_stub or 'method' not in sig_stub:
            fail(EXIT_SCHEMA_VIOLATION, "signature_stub missing signer or method")

def validate_envelope_and_taxonomy(data: Dict[str, Any], ignore_skew: bool, allow_deprecated: bool):
    required = {
        "packet_id", "packet_type", "schema_version", "created_at",
        "source_agent", "target_agent", "chain_id", "priority",
        "nonce", "ttl_hours"
    }
    
    for field in required:
        if field not in data:
            fail(EXIT_SCHEMA_VIOLATION, f"Missing required envelope field: {field}")

    validate_uuid(data['packet_id'], 'packet_id')
    validate_uuid(data['chain_id'], 'chain_id')
    validate_uuid(data['nonce'], 'nonce')
    validate_timestamp(data['created_at'], 'created_at', ignore_skew)

    if data['schema_version'] != REQUIRED_SCHEMA_VERSION:
        fail(EXIT_VERSION_INCOMPATIBLE, f"Unsupported schema version: {data['schema_version']}")

    # Taxonomy Enforcement (P1.2)
    ptype = data['packet_type']
    if ptype not in CORE_PACKET_TYPES:
        if ptype in DEPRECATED_PACKET_TYPES:
            if not allow_deprecated:
                fail(EXIT_SCHEMA_VIOLATION, f"Deprecated packet type {ptype} requires --allow-deprecated")
        else:
            fail(EXIT_SCHEMA_VIOLATION, f"Unknown packet type: {ptype}")

    if 'is_draft' in data and not isinstance(data['is_draft'], bool):
        fail(EXIT_SCHEMA_VIOLATION, "is_draft must be boolean")

def validate_payload(data: Dict[str, Any]):
    ptype = data['packet_type']
    
    # Payload Allowlist
    envelope_fields = {
        "packet_id", "packet_type", "schema_version", "created_at",
        "source_agent", "target_agent", "chain_id", "parent_packet_id", 
        "priority", "nonce", "ttl_hours", "is_draft", "compression", "tags",
        "signature_stub"
    }

    payload_specs = {
        "COUNCIL_REVIEW_PACKET": {"review_type", "subject_ref", "subject_summary", "objective", "context_refs", "urgency_rationale"},
        "COUNCIL_APPROVAL_PACKET": {"verdict", "review_packet_id", "subject_hash", "rationale", "conditions", "blocking_issues", "votes"},
        "GATE_APPROVAL_PACKET": {"gate_id", "status", "approver", "evidence_refs", "waiver_rationale"},
        "BUILD_PACKET": {"goal", "scope", "spec", "tasks", "acceptance_criteria"},
        "REVIEW_PACKET": {"outcome", "build_packet_id", "artifacts_produced", "diff_summary", "verification_evidence"},
        "FIX_PACKET": {"source_packet_id", "issues"},
        "ESCALATION_PACKET": {"reason", "level", "context_summary", "options_presented", "recommendation"},
        "HANDOFF_PACKET": {"reason", "current_state_summary", "next_step_goal", "knowledge_transfer", "attachments"},
        "STATE_MANAGEMENT_PACKET": {"action", "state_ref", "description", "force"},
        "CONTEXT_REQUEST_PACKET": {"requester_role", "topic", "query", "max_items"},
        "CONTEXT_RESPONSE_PACKET": {"request_packet_id", "human_name", "repo_refs", "packet_refs"},
        "DOC_STEWARD_REQUEST_PACKET": {"mission_type", "scope_paths", "instructions", "constraints"},
    }

    allowed_payload_fields = payload_specs.get(ptype, set())
    all_keys = set(data.keys())
    # envelope mixed with payload
    unknown = all_keys - envelope_fields - allowed_payload_fields
    
    if unknown:
        fail(EXIT_SCHEMA_VIOLATION, f"Unknown fields for type {ptype}: {unknown}")

    if ptype == "COUNCIL_APPROVAL_PACKET":
        if "review_packet_id" not in data or "subject_hash" not in data:
            fail(EXIT_LINEAGE_VIOLATION, "COUNCIL_APPROVAL_PACKET missing lineage fields")

def validate_bundle(directory: str):
    # Replay Enforcement (P0.3)
    files = sorted(glob.glob(os.path.join(directory, "*")))
    seen_nonces = {}
    
    print(f"Validating bundle: {directory} ({len(files)} files)")
    
    for fpath in files:
        if not (fpath.endswith('.yaml') or fpath.endswith('.md')):
            continue
            
        try:
            data = extract_packet_data(fpath)
        except Exception as e:
            # If a file in bundle is invalid, the bundle fails?
            # Or just skip? Fail-closed -> Fail bundle.
            fail(EXIT_FAIL_GENERIC, f"Bundle file {fpath} unreadable: {e}")

        # Check Nonce Uniqueness
        if 'nonce' in data:
            nonce = data['nonce']
            if nonce in seen_nonces:
                fail(EXIT_REPLAY_VIOLATION, f"Duplicate nonce {nonce} in {fpath} (seen in {seen_nonces[nonce]})")
            seen_nonces[nonce] = fpath

def main():
    parser = argparse.ArgumentParser(description="LifeOS Packet Validator (Strict v1.1)")
    parser.add_argument("path", nargs='?', help="Path to packet file or bundle directory")
    parser.add_argument("--bundle", help="Directory containing bundle of packets", metavar="DIR")
    parser.add_argument("--ignore-skew", action="store_true", help="Ignore clock skew checks")
    parser.add_argument("--allow-deprecated", action="store_true", help="Allow deprecated packet types")
    args = parser.parse_args()

    # Mode Selection
    if args.bundle:
        if not os.path.isdir(args.bundle):
             fail(EXIT_FAIL_GENERIC, f"Bundle path is not a directory: {args.bundle}")
        validate_bundle(args.bundle)
        # Bundle mode currently only checks replay/integrity across set. 
        # Should it also validate each packet fully? 
        # Requirement "Collect nonces... if repeats fail".
        # Implies we also validate structure to get nonce. 
        # I'll stick to mostly replay check + basic extraction unless user wants deep validation of each.
        # But failing to extract = fail bundle.
        print("[PASS] Bundle replay check passed.")
        sys.exit(EXIT_PASS)
    elif args.path:
        data = extract_packet_data(args.path)
        validate_envelope_and_taxonomy(data, args.ignore_skew, args.allow_deprecated)
        validate_ttl(data)
        validate_signature(data)
        validate_payload(data)
        print("[PASS] Packet valid.")
        sys.exit(EXIT_PASS)
    else:
        parser.print_help()
        sys.exit(EXIT_FAIL_GENERIC)

if __name__ == "__main__":
    main()
