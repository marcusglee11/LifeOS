
import pytest
import subprocess
import os
import uuid
import yaml
from datetime import datetime, timezone, timedelta

VALIDATOR_SCRIPT = "scripts/validate_packet.py"

def run_validator(path, args=[]):
    cmd = ["python", VALIDATOR_SCRIPT, path] + args
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr

def run_bundle_validator(dir_path):
    cmd = ["python", VALIDATOR_SCRIPT, "--bundle", dir_path]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr

@pytest.fixture
def base_envelope():
    return {
        "packet_id": str(uuid.uuid4()),
        "packet_type": "HANDOFF_PACKET",
        "schema_version": "1.1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_agent": "TestSrc",
        "target_agent": "TestDst",
        "chain_id": str(uuid.uuid4()),
        "priority": "P2_NORMAL",
        "nonce": str(uuid.uuid4()),
        "ttl_hours": 72,
        "is_draft": False,
        "signature_stub": { "signer": "Me", "method": "STUB", "attestation": "ok" }
    }

# --- P0.1 Clock Skew ---
def test_clock_skew_fail(tmp_path, base_envelope):
    data = base_envelope.copy()
    # 2 hours in past > 300s
    old_time = datetime.now(timezone.utc) - timedelta(seconds=600)
    data['created_at'] = old_time.isoformat()
    
    p = tmp_path / "skew_fail.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 3 # EXIT_SECURITY_VIOLATION
    assert "Clock skew" in err

def test_clock_skew_ignore(tmp_path, base_envelope):
    data = base_envelope.copy()
    old_time = datetime.now(timezone.utc) - timedelta(seconds=600)
    data['created_at'] = old_time.isoformat()
    
    p = tmp_path / "skew_ignore.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p), args=["--ignore-skew"])
    assert code == 0

# --- P0.2 TTL ---
def test_ttl_fail(tmp_path, base_envelope):
    data = base_envelope.copy()
    data['ttl_hours'] = 1
    # Created 2 hours ago -> Age 2h > TTL 1h
    old_time = datetime.now(timezone.utc) - timedelta(hours=2)
    data['created_at'] = old_time.isoformat()
    
    p = tmp_path / "ttl_fail.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    # Must use ignore-skew otherwise skew check fails first!
    code, out, err = run_validator(str(p), args=["--ignore-skew"])
    assert code == 3 # EXIT_SECURITY_VIOLATION
    assert "TTL expired" in err

# --- P0.3 Replay (Bundle) ---
def test_bundle_replay_fail(tmp_path, base_envelope):
    nonce = str(uuid.uuid4())
    data1 = base_envelope.copy()
    data1['nonce'] = nonce
    data1['packet_id'] = str(uuid.uuid4())
    
    data2 = base_envelope.copy()
    data2['nonce'] = nonce # Collision
    data2['packet_id'] = str(uuid.uuid4())

    (tmp_path / "p1.yaml").write_text(yaml.dump(data1), encoding='utf-8')
    (tmp_path / "p2.yaml").write_text(yaml.dump(data2), encoding='utf-8')
    
    code, out, err = run_bundle_validator(str(tmp_path))
    assert code == 5 # EXIT_REPLAY_VIOLATION
    assert "Duplicate nonce" in err

# --- P0.4 Signatures ---
def test_signature_missing_nondraft(tmp_path, base_envelope):
    data = base_envelope.copy()
    data['is_draft'] = False
    del data['signature_stub'] # Missing
    
    p = tmp_path / "sig_fail.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 3
    assert "Signature stub required" in err

def test_signature_optional_draft(tmp_path, base_envelope):
    data = base_envelope.copy()
    data['is_draft'] = True
    if 'signature_stub' in data:
        del data['signature_stub']
    
    p = tmp_path / "sig_draft_ok.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 0

def test_signature_council_approval_always_required(tmp_path, base_envelope):
    data = base_envelope.copy()
    data['packet_type'] = "COUNCIL_APPROVAL_PACKET"
    data['is_draft'] = True # Even if draft
    if 'signature_stub' in data:
        del data['signature_stub']
    
    # Payload minimal
    data['verdict'] = "APPROVED"
    data['review_packet_id'] = str(uuid.uuid4())
    data['subject_hash'] = "abc"
    data['rationale'] = "r"
    
    p = tmp_path / "council_sig_fail.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 3
    assert "Signature stub required" in err

# --- P1.2 Taxonomy ---
def test_deprecated_taxonomy_fail(tmp_path, base_envelope):
    data = base_envelope.copy()
    data['packet_type'] = "FIX_PACKET" # Deprecated
    data['source_packet_id'] = str(uuid.uuid4())
    data['issues'] = []
    
    p = tmp_path / "dep_fail.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 2
    assert "Deprecated packet type" in err

def test_deprecated_taxonomy_allow(tmp_path, base_envelope):
    data = base_envelope.copy()
    data['packet_type'] = "FIX_PACKET"
    data['source_packet_id'] = str(uuid.uuid4())
    data['issues'] = []
    
    p = tmp_path / "dep_pass.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p), args=["--allow-deprecated"])
    assert code == 0
