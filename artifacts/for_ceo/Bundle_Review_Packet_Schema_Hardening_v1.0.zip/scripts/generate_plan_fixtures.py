
import os

FIXTURE_DIR = r"c:\Users\cabra\Projects\LifeOS\tests\fixtures\plan_packet"
os.makedirs(FIXTURE_DIR, exist_ok=True)

BASE = """# Scope Envelope
- **In-Scope Artefacts (resolved by discovery)**: X

# Proposed Changes
- P

# Claims
- **Claim**: C
  - **Type**: policy_mandate
  - **Evidence Pointer**: path/to/file:L1-L10
  - **Status**: asserted

# Targets
- T

# Validator Contract
- O

# Verification Matrix
| Case | Input | Expected | Code | Prefix |
|---|---|---|---|---|
| P1 | i | PASS | | |
| F1 | i | FAIL | C1 | |
| F2 | i | FAIL | C2 | |
| F3 | i | FAIL | C3 | |
| F4 | i | FAIL | C4 | |
| F5 | i | FAIL | C5 | |

# Migration Plan
- M

# Governance Impact
- G
"""

FILES = {
    "pass.md": BASE,
    "fail_01_sec.md": BASE.replace("# Scope Envelope", ""),
    "fail_02_order.md": BASE.replace("# Proposed Changes", "# Scope Envelope").replace("# Scope Envelope", "# Proposed Changes", 1),
    "fail_03_claim.md": BASE.replace("- **Evidence Pointer**: path/to/file:L1-L10", ""), # Proven/Asserted logic check needed in validator
    # Note: Validator warns on asserted+missing, fails on proven+missing.
    # To test PPV003 Fail, we need status proven.
    "fail_03_proven.md": BASE.replace("asserted", "proven").replace("- **Evidence Pointer**: path/to/file:L1-L10", ""),
    "fail_04_ptr.md": BASE.replace("path/to/file:L1-L10", "bad pointer"),
    "fail_06_matrix.md": BASE.replace("| F5 | i | FAIL | C5 | |", "") # Less than 5 fails
}

for name, content in FILES.items():
    with open(os.path.join(FIXTURE_DIR, name), "w", encoding="utf-8") as f:
        f.write(content)
print(f"Generated {len(FILES)} PPV fixtures")
