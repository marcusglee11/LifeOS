
import os

FIXTURE_DIR = r"c:\Users\cabra\Projects\LifeOS\tests\fixtures\review_packet"
os.makedirs(FIXTURE_DIR, exist_ok=True)

BASE = """---
artifact_id: "uuid"
artifact_type: "REVIEW_PACKET"
schema_version: "1.0.0"
created_at: "2026-01-01T00:00:00Z"
author: "Antigravity"
version: "1.0"
status: "PENDING_REVIEW"
terminal_outcome: "PASS"
closure_evidence: {}
---

# Review_Packet_Mission_v1.0

# Scope Envelope
- S

# Summary
S

# Issue Catalogue
| Id | D | R | S |
|---|---|---|---|

# Acceptance Criteria
| C | S | E | H |
|---|---|---|---|

# Closure Evidence Checklist
| Category | Requirement | Verified |
|----------|-------------|----------|
| **Provenance** | Code | [Hash] |
| **Artifacts** | Ledger | [Path] |
| **Repro** | Cmd | [Cmd] |
| **Governance** | Routing | [Ref] |
| **Outcome** | Proof | [PASS] |

# Non-Goals
- N

# Appendix
"""

FILES = {
    "pass.md": BASE,
    "fail_01_scope.md": BASE.replace("# Scope Envelope", ""),
    "fail_02_order.md": BASE.replace("# Summary", "# Scope Envelope").replace("# Scope Envelope", "# Summary", 1), # crude swap
    "fail_05_check.md": BASE.replace("| **Provenance** |", "| **Missing** |"),
    # fail 06 requires more complex regex match failure simulation - empty Verified column
    "fail_06_verified.md": BASE.replace("| [Hash] |", "| |"),
    "fail_11_yaml.md": BASE.replace('closure_evidence: {}', '')
}

for name, content in FILES.items():
    with open(os.path.join(FIXTURE_DIR, name), "w", encoding="utf-8") as f:
        f.write(content)
print(f"Generated {len(FILES)} Review Packet fixtures")
