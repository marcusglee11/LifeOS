#!/usr/bin/env python3
"""
OpenCode CI Runner (CT-2 Phase 3 v2.0)
======================================

Broadened CI runner for doc-steward gate per CEO waiver 2026-01-09.
All structural operations allowed. Path security checks retained.
"""

import argparse
import time
import requests
import subprocess
import sys
import os
import json
import threading
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple

# Add scripts directory to path for imports if not already there
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

# Import hardened policy module
import opencode_gate_policy as policy
from opencode_gate_policy import ReasonCode

# Import canonical defaults from single source of truth
try:
    # Add parent directory to path for runtime imports
    _repo_root = os.path.dirname(_script_dir)
    if _repo_root not in sys.path:
        sys.path.insert(0, _repo_root)
    from runtime.agents.models import DEFAULT_MODEL, validate_config
except ImportError:
    DEFAULT_MODEL = "minimax-m2.1-free"
    def validate_config():
        return True, "Fallback config"

# ============================================================================
# LOGGING
# ============================================================================
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    YELLOW = '\033[93m'
    RESET = '\033[0m'

# Global log buffer for evidence bundle
_log_buffer = []

def log(msg, level="info"):
    timestamp = datetime.now().isoformat(sep="T", timespec="seconds")
    color = Colors.RESET
    if level == "error": color = Colors.RED
    elif level == "ok": color = Colors.GREEN
    elif level == "gov": color = Colors.YELLOW
    elif level == "info": color = Colors.BLUE
    
    log_line = f"[{level.upper()}] [{timestamp}] {msg}"
    _log_buffer.append(log_line)
    print(f"{color}{log_line}{Colors.RESET}")

def get_log_buffer() -> str:
    return "\n".join(_log_buffer)

def clear_log_buffer():
    _log_buffer.clear()

def load_steward_key():
    """Load the steward API key from env or .env file."""
    # Priority: ZEN_STEWARD_KEY > STEWARD_OPENROUTER_KEY
    key = os.environ.get("ZEN_STEWARD_KEY") or os.environ.get("STEWARD_OPENROUTER_KEY")
    if not key:
        try:
            with open(".env", "r") as f:
                for line in f:
                    if line.startswith("ZEN_STEWARD_KEY="):
                        key = line.split("=", 1)[1].strip()
                        break
                if not key:
                    f.seek(0)
                    for line in f:
                        if line.startswith("STEWARD_OPENROUTER_KEY="):
                            key = line.split("=", 1)[1].strip()
                            break
        except FileNotFoundError:
            pass
    
    if key:
        log("Steward API Key loaded (present)", "info")
    else:
        log("Steward API Key NOT found", "error")
    return key

# ============================================================================
# ENVELOPE VALIDATION (POST-DIFF)
# ============================================================================
def validate_diff_entry(status: str, path: str, old_path: Optional[str] = None) -> Tuple[bool, Optional[str]]:
    """
    Validate a single diff entry against Phase 3 envelope.
    
    Per CEO waiver 2026-01-09: All operations allowed, structural ops audited.
    Returns (allowed, reason_code or None).
    Order: path security -> allowlist -> (extension check dropped)
    """
    norm_path = policy.normalize_path(path)
    
    # 1. D/R/C operations now ALLOWED per CEO waiver (audit only, no block)
    # Previously blocked, now just logged for audit trail
    
    # 2. Path security checks (still enforced)
    safe, security_reason = policy.check_path_security(norm_path, os.getcwd())
    if not safe:
        return (False, security_reason)
    
    # 3. Denylist cleared per CEO waiver - skip check
    # Previously: is_denied, deny_reason = policy.matches_denylist(norm_path)
    
    # 4. Allowlist check (expanded per CEO waiver)
    if not policy.matches_allowlist(norm_path):
        return (False, ReasonCode.OUTSIDE_ALLOWLIST_BLOCKED)
    
    # 5. Extension check dropped per CEO waiver
    # Previously: ext_ok, ext_reason = policy.check_extension_under_docs(norm_path)
    
    # 6. Review packets: relax add-only restriction per CEO waiver
    # All operations now allowed on review_packets/
    
    return (True, None)

def validate_all_diff_entries(parsed_diff: List[tuple]) -> List[Tuple[str, str, str]]:
    """
    Validate all parsed diff entries.
    
    Returns list of (path, operation, reason_code) for blocked entries.
    """
    blocked = []
    for entry in parsed_diff:
        if len(entry) == 2:
            status, path = entry
            old_path = None
        else:
            status, old_path, path = entry  # R/C have old and new paths
        
        allowed, reason = validate_diff_entry(status, path, old_path)
        if not allowed:
            blocked.append((path, status, reason))
            # For R/C, also record the old path
            if old_path:
                blocked.append((old_path, status, reason))
    
    return blocked

# ============================================================================
# EVIDENCE GENERATION
# ============================================================================
def generate_evidence_bundle(status: str, reason: Optional[str], mode: str, task: Dict[str, Any], 
                            parsed_diff: List[tuple] = None, blocked_entries: List[tuple] = None):
    """Generate the deterministic evidence bundle for the mission."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    mission_id = f"mission_{timestamp}"
    evidence_path = os.path.join(policy.EVIDENCE_ROOT, mission_id)
    os.makedirs(evidence_path, exist_ok=True)
    
    # exit_report.json
    report = {
        "status": status,
        "reason_code": reason,
        "mode": mode,
        "timestamp": datetime.now().isoformat(),
        "task": task,
        "blocked_entries": blocked_entries or []
    }
    with open(os.path.join(evidence_path, "exit_report.json"), "w") as f:
        json.dump(report, f, indent=2)
    
    # changed_files.json (sorted by path for determinism)
    changed = []
    if parsed_diff:
        for entry in parsed_diff:
            if len(entry) == 2:
                changed.append({"status": entry[0], "path": entry[1]})
            else:
                changed.append({"status": entry[0], "old_path": entry[1], "new_path": entry[2]})
    # Sort by path (or new_path for renames/copies) for deterministic output
    changed.sort(key=lambda x: policy.normalize_path(x.get("path") or x.get("new_path", "")))
    
    with open(os.path.join(evidence_path, "changed_files.json"), "w") as f:
        json.dump(changed, f, indent=2)
    
    # classification.json
    classification = {
        "is_governance": any(policy.matches_denylist(path)[0] for path in task.get("files", [])),
        "risk_level": "P0" if any(policy.matches_denylist(path)[0] for path in task.get("files", [])) else "P1",
        "envelope_violations": len(blocked_entries) if blocked_entries else 0
    }
    with open(os.path.join(evidence_path, "classification.json"), "w") as f:
        json.dump(classification, f, indent=2)
    
    # runner.log
    log_content = get_log_buffer()
    truncated_log, _ = policy.truncate_log(log_content)
    with open(os.path.join(evidence_path, "runner.log"), "w") as f:
        f.write(truncated_log)
    
    # hashes.json
    hashes = {}
    for filename in ["exit_report.json", "changed_files.json", "classification.json", "runner.log"]:
        p = os.path.join(evidence_path, filename)
        if os.path.exists(p):
            hashes[filename] = policy.compute_file_hash(p)
            
    with open(os.path.join(evidence_path, "hashes.json"), "w") as f:
        json.dump(hashes, f, indent=2)
        
    log(f"Evidence bundle generated: {evidence_path}", "ok")
    return evidence_path

# ============================================================================
# INPUT VALIDATION
# ============================================================================
def validate_task_input(task_str):
    """Validate task is JSON with required schema. Reject free-text."""
    try:
        task = json.loads(task_str)
    except json.JSONDecodeError:
        log("Free-text input rejected. Phase 3 requires JSON-structured tasks.", "error")
        return None
    
    required = ["files", "action", "instruction"]
    for key in required:
        if key not in task:
            log(f"Missing required key in task JSON: {key}", "error")
            return None
    
    # Phase 3: All operations allowed per CEO waiver 2026-01-09
    valid_actions = ["create", "modify", "delete", "rename", "move", "copy"]
    if task["action"] not in valid_actions:
        log(f"Invalid action: {task['action']}. Valid actions: {valid_actions}", "error")
        return None
    
    return task

# ============================================================================
# WATCHDOG / TIMEOUT
# ============================================================================
class MissionTimeout(Exception):
    """Raised when mission exceeds timeout."""
    pass

def run_with_timeout(func, timeout_seconds, *args, **kwargs):
    """Run function with timeout. Cross-platform using threading."""
    result = [None]
    exception = [None]
    
    def target():
        try:
            result[0] = func(*args, **kwargs)
        except Exception as e:
            exception[0] = e
    
    thread = threading.Thread(target=target, daemon=True)
    thread.start()
    thread.join(timeout=timeout_seconds)
    
    if thread.is_alive():
        raise MissionTimeout(f"Mission exceeded {timeout_seconds}s timeout")
    if exception[0]:
        raise exception[0]
    return result[0]

# ============================================================================
# EPHEMERAL SERVER LIFECYCLE
# ============================================================================
import tempfile
import shutil

def create_isolated_config(api_key, model):
    temp_dir = tempfile.mkdtemp(prefix="opencode_steward_")
    config_subdir = os.path.join(temp_dir, "opencode")
    os.makedirs(config_subdir, exist_ok=True)
    data_subdir = os.path.join(temp_dir, ".local", "share", "opencode")
    os.makedirs(data_subdir, exist_ok=True)
    
    # Determine provider based on model naming or defaults
    if "minimax" in model.lower():
        provider = "zen" # Zen endpoint often maps to 'zen' or 'anthropic' internal logic in server
        # For our environment, we'll provide keys for both to be safe
        auth_data = {
            "zen": {"type": "api", "key": api_key},
            "openrouter": {"type": "api", "key": api_key}
        }
    else:
        auth_data = {"openrouter": {"type": "api", "key": api_key}}

    with open(os.path.join(data_subdir, "auth.json"), "w") as f:
        json.dump(auth_data, f, indent=2)
    
    config_data = {
        "model": model, 
        "$schema": "https://opencode.ai/config.json"
    }
    
    # If using Zen, we might need to specify the base URL in config too
    # Using the standard Zen endpoint from models.yaml
    if "minimax" in model.lower():
        config_data["upstream_base_url"] = "https://opencode.ai/zen/v1/messages"

    with open(os.path.join(config_subdir, "opencode.json"), "w") as f:
        json.dump(config_data, f, indent=2)
    
    return temp_dir

def cleanup_isolated_config(config_dir):
    if config_dir and os.path.exists(config_dir):
        try: shutil.rmtree(config_dir)
        except: pass

def start_ephemeral_server(port, config_dir, api_key):
    log(f"Starting ephemeral OpenCode server on port {port}", "info")
    env = os.environ.copy()
    if os.name != "nt":
        env["APPDATA"], env["XDG_CONFIG_HOME"], env["USERPROFILE"], env["HOME"] = config_dir, config_dir, config_dir, config_dir
    env["OPENROUTER_API_KEY"] = api_key
    env["OPENAI_API_KEY"], env["ANTHROPIC_API_KEY"] = "", ""
    
    # Process group flags for cross-platform cleanup
    creationflags = 0
    if os.name == "nt":
        import subprocess as sp
        creationflags = sp.CREATE_NEW_PROCESS_GROUP
        
    try:
        return subprocess.Popen(
            ["opencode", "serve", "--port", str(port)],
            env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, 
            shell=True if os.name == "nt" else False,
            start_new_session=True if os.name != "nt" else False,
            creationflags=creationflags
        )
    except Exception as e:
        log(f"Failed to start ephemeral server: {e}", "error")
        return None

def stop_ephemeral_server(process):
    if not process:
        return
    log(f"Stopping ephemeral server (PID {process.pid})", "info")
    try:
        if os.name == "nt":
            # Windows: kill process tree
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(process.pid)],
                capture_output=True, timeout=10
            )
        else:
            # Unix: kill process group
            import signal
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            time.sleep(1)
            os.killpg(os.getpgid(process.pid), signal.SIGKILL)
    except Exception:
        pass
    finally:
        try:
            process.terminate()
            process.wait(timeout=5)
        except subprocess.TimeoutExpired: 
            process.kill()

# ============================================================================
# OPENCODE SERVER INTERFACE
# ============================================================================
def wait_for_server(base_url, timeout=30):
    start = time.time()
    while time.time() - start < timeout:
        try:
            if requests.get(f"{base_url}/global/health", timeout=1).status_code == 200:
                return True
        except: pass
        time.sleep(1)
    return False

def run_mission(base_url, model, instruction):
    try:
        # P0.3: Explicit connect/read timeouts
        resp = requests.post(
            f"{base_url}/session", 
            json={"title": "Steward Mission", "model": model}, 
            timeout=(5, 30)
        )
        if resp.status_code != 200: return False
        session_id = resp.json()["id"]
        requests.post(
            f"{base_url}/session/{session_id}/message", 
            json={"parts": [{"type": "text", "text": instruction}]}, 
            timeout=(5, 120)
        )
        return session_id
    except: return False

# ============================================================================
# MAIN
# ============================================================================
def main():
    parser = argparse.ArgumentParser(description="OpenCode CI Runner (CT-2 Phase 3 v2.0) - Broadened per CEO waiver")
    parser.add_argument("--port", type=int, default=62586)
    parser.add_argument("--model", type=str, default=DEFAULT_MODEL)
    parser.add_argument("--task", type=str, help="JSON-structured task (direct string)")
    parser.add_argument("--task-file", type=str, help="Path to JSON task file (artifacts/ only)")
    parser.add_argument("--mission-timeout", type=int, default=300,
                        help="Overall mission timeout in seconds (default: 300)")
    # NO --override-foundations flag. Period.
    args = parser.parse_args()
    
    repo_root = os.getcwd()
    steward_api_key = load_steward_key()
    
    task_json = None
    
    # Priority 1: Task File (Safe for large payloads)
    if args.task_file:
        # P0 Validation: Strict Allowlist & Containment
        norm_path = args.task_file.replace("\\", "/")
        
        # 1. No absolute paths, no traversal
        if os.path.isabs(norm_path) or ".." in norm_path:
            log(f"Security violation: path traversal or absolute path rejected: {args.task_file}", "error")
            sys.exit(1)
            
        # 2. Strict Allowlist prefix
        if not norm_path.startswith("artifacts/"):
            log(f"Security violation: task file must be in artifacts/: {args.task_file}", "error")
            sys.exit(1)
            
        # 3. Regular file check (no invalid types)
        if not os.path.isfile(norm_path):
             log(f"Invalid task file (not a file): {args.task_file}", "error")
             sys.exit(1)

        # 4. Symlink rejection
        if os.path.islink(norm_path):
            log(f"Security violation: symlinks rejected: {args.task_file}", "error")
            sys.exit(1)
            
        # 5. Realpath containment (Double-check)
        try:
            real_path = os.path.realpath(norm_path)
            real_artifacts = os.path.realpath("artifacts")
            if not real_path.startswith(real_artifacts + os.sep):
                 log(f"Security violation: realpath escape detected: {real_path}", "error")
                 sys.exit(1)
        except Exception as e:
            log(f"Security check failed: {e}", "error")
            sys.exit(1)
            
        # Load Content
        try:
            with open(norm_path, 'r', encoding='utf-8') as f:
                task_json = f.read()
        except Exception as e:
            log(f"Failed to read task file: {e}", "error")
            sys.exit(1)
            
    # Priority 2: Direct Arg
    elif args.task:
        task_json = args.task
        
    else:
        log("Either --task or --task-file is required.", "error")
        sys.exit(1)
    
    task = validate_task_input(task_json)
    if not task: 
        sys.exit(1)
    
    # ========== PRE-START CHECKS (symlink on declared files) ==========
    for path in task["files"]:
        is_sym, reason = policy.check_symlink(path, repo_root)
        if is_sym:
            generate_evidence_bundle("BLOCK", reason, "PRE_START", task)
            log(f"Symlink rejected: {path}", "error")
            sys.exit(1)
    
    # ========== SERVER SETUP ==========
    config_dir = create_isolated_config(steward_api_key, args.model)
    server_process = start_ephemeral_server(args.port, config_dir, steward_api_key)
    if not server_process:
        cleanup_isolated_config(config_dir)
        sys.exit(1)
    
    if not wait_for_server(f"http://127.0.0.1:{args.port}"):
        stop_ephemeral_server(server_process)
        cleanup_isolated_config(config_dir)
        log("Server timeout", "error")
        sys.exit(1)
    
    # ========== EXECUTE MISSION ==========
    log(f"Executing mission (timeout={args.mission_timeout}s)", "info")
    try:
        session_id = run_with_timeout(
            run_mission, 
            args.mission_timeout,
            f"http://127.0.0.1:{args.port}", 
            args.model, 
            task["instruction"]
        )
    except MissionTimeout as e:
        log(f"MISSION TIMEOUT: {e}", "error")
        generate_evidence_bundle("TIMEOUT", policy.ReasonCode.MISSION_TIMEOUT, "EXECUTION", task)
        stop_ephemeral_server(server_process)
        cleanup_isolated_config(config_dir)
        sys.exit(2)
    except Exception as e:
        log(f"Mission execution failed: {e}", "error")
        stop_ephemeral_server(server_process)
        cleanup_isolated_config(config_dir)
        sys.exit(1)
    
    # ========== POST-EXECUTION: GET DIFF AND VALIDATE ENVELOPE ==========
    log("Validating post-execution diff against envelope", "info")
    parsed, mode, error = policy.execute_diff_and_parse(repo_root)
    
    if error:
        generate_evidence_bundle("BLOCK", error, mode, task)
        log(f"Diff acquisition failed: {error}", "error")
        subprocess.run(["git", "reset", "--hard", "HEAD"], check=False)
        stop_ephemeral_server(server_process)
        cleanup_isolated_config(config_dir)
        sys.exit(1)
    
    if not parsed:
        parsed = []
    
    # Validate ALL diff entries against envelope
    blocked_entries = validate_all_diff_entries(parsed)
    
    if blocked_entries:
        first_block = blocked_entries[0]
        generate_evidence_bundle("BLOCK", first_block[2], mode, task, parsed, blocked_entries)
        log(f"Envelope violation: {first_block[0]} ({first_block[1]}) - {first_block[2]}", "error")
        for entry in blocked_entries[1:5]:  # Log up to 5
            log(f"  Additional violation: {entry[0]} ({entry[1]}) - {entry[2]}", "error")
        subprocess.run(["git", "reset", "--hard", "HEAD"], check=False)
        stop_ephemeral_server(server_process)
        cleanup_isolated_config(config_dir)
        sys.exit(1)
    
    # Check symlinks again for new files
    for entry in parsed:
        path = entry[1] if len(entry) == 2 else entry[2]
        is_sym, reason = policy.check_symlink(path, repo_root)
        if is_sym:
            generate_evidence_bundle("BLOCK", reason, mode, task, parsed)
            log(f"New symlink detected: {path}", "error")
            subprocess.run(["git", "reset", "--hard", "HEAD"], check=False)
            stop_ephemeral_server(server_process)
            cleanup_isolated_config(config_dir)
            sys.exit(1)

    # Success
    generate_evidence_bundle("PASS", None, mode, task, parsed)
    log("MISSION SUCCESS - All changes within envelope", "ok")
    
    # Cleanup
    stop_ephemeral_server(server_process)
    cleanup_isolated_config(config_dir)

if __name__ == "__main__":
    main()
