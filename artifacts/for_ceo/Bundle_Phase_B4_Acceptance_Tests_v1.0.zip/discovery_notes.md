# Discovery Notes: Phase B.4 Acceptance Validation

**Date**: 2026-01-15
**Purpose**: Map artifact paths and stable identifiers used in acceptance tests.

## 1. Artifact Path Mapping

| Artifact | Path Pattern | Source |
|----------|--------------|--------|
| **Waiver Request** | `artifacts/loop_state/WAIVER_REQUEST_{run_id}.md` | `runtime/orchestration/loop/waiver.py` |
| **Waiver Decision** | `artifacts/loop_state/WAIVER_DECISION_{run_id}.json` | `scripts/loop/approve_waiver.py` |
| **Attempt Ledger** | `artifacts/loop_state/attempt_ledger.jsonl` | `runtime/orchestration/loop/ledger.py` |
| **Preflight Checklist** | `artifacts/loop_state/PREFLIGHT_CHECK_{run_id}_{phase}.json` | `runtime/orchestration/loop/checklists.py` |
| **Postflight Checklist** | `artifacts/loop_state/POSTFLIGHT_CHECK_{run_id}_{phase}.json` | `runtime/orchestration/loop/checklists.py` |
| **Terminal Packet** | `artifacts/CEO_Terminal_Packet.md` | `runtime/orchestration/missions/autonomous_build_cycle.py` |
| **Backlog (Debt)** | `docs/11_admin/BACKLOG.md` | `runtime/orchestration/loop/waiver.py` |

## 2. Stable Identifiers

### Checklist Items (runtime/orchestration/loop/checklists.py)

**Preflight (PPV)**

- `PF-1`: Schema validation
- `PF-2`: Run ID match
- `PF-3`: Determinism anchors (policy_hash)
- `PF-4`: Artifacts present
- `PF-5`: Evidence linkage
- `PF-6`: Governance surface scan
- `PF-7`: Budget state coherence
- `PF-8`: Metadata completeness

**Postflight (POFV)**

- `POF-1`: Terminal outcome validity
- `POF-2`: Run ID match
- `POF-3`: Determinism anchors
- `POF-4`: Debt registration format
- `POF-5`: Artifacts present
- `POF-6`: Next actions present

### Ledger Fields (runtime/orchestration/loop/ledger.py)

- `policy_hash`: `policy_hash_canonical` (config_loader.py)
- `handoff_hash`: SHA256 of handoff context
- `attempt_id`: 1-based index

### Governance Outcomes (runtime/orchestration/loop/taxonomy.py)

- `ESCALATION_REQUESTED`: Triggered by governance surface touch or protected path change
- `WAIVER_REQUESTED`: Triggered by retry exhaustion on eligible failure
- `BLOCKED`: Triggered by ineligible failure or critical error

### Debt ID Format

- Format: `DEBT-{run_id}`
- Constraint: No line numbers (no `:`)
- Source: `runtime/orchestration/loop/waiver.py`
