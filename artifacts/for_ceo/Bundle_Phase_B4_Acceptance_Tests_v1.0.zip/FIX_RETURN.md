# Phase B.4 Acceptance Tests - Fix Return

**Date**: 2026-01-15
**Status**: PRIMARY GOAL ACHIEVED ✅, SECONDARY GOAL BLOCKED ⚠️

---

## Executive Summary

**PRIMARY GOAL: ✅ COMPLETE**
- `runtime/tests/orchestration/missions/test_loop_acceptance.py`: **20/20 PASSING (100%, 0 skips)**
- All P0 issues resolved:
  - P0.1: Waiver request artifact emission ✅
  - P0.2: Ledger corruption in resume scenarios ✅
  - P0.3: Deterministic test assertions (no pytest.skip()) ✅

**SECONDARY GOAL: ⚠️ PARTIAL**
- `runtime/tests/orchestration/missions/test_loop_waiver_workflow.py`: **6/8 passing (75%)**
- 2 waiver emission tests blocked (redundant with passing acceptance tests)
- See `BLOCKED_Waiver_Workflow_Tests.md` for decision options

---

## P0.1: Waiver Request Artifact Emission

### Issue
Waiver request packets were not being emitted when retry limits exhausted, causing 2 acceptance tests to fail.

### Root Cause
The waiver packet_data was missing the `attempt_id` field, causing Preflight Validation (PPV) to fail silently and block artifact emission.

**Code Location**: `runtime/orchestration/missions/autonomous_build_cycle.py:547`

### Fix Applied
```python
# BEFORE (line 544-563):
packet_data = {
    "schema_version": "waiver_request_v1.0",
    "run_id": context.run_id,
    # MISSING: attempt_id
    "timestamp": timestamp,
    ...
}

# AFTER (line 544-563):
packet_data = {
    "schema_version": "waiver_request_v1.0",
    "run_id": context.run_id,
    "attempt_id": attempt_count + 1,  # Added - required by PPV
    "timestamp": timestamp,
    ...
}
```

### Verification
- PPV validation now passes (PF-1: Schema pass)
- Waiver request packets emitted at `artifacts/loop_state/WAIVER_REQUEST_*.md`
- Test evidence: `test_phaseb_waiver_approval_pass_via_waiver_approved` PASSES

**Evidence**: `pytest_test_loop_acceptance.log.txt` lines showing PASS for waiver tests

---

## P0.2: Ledger Corruption on Resume

### Issue
Resume scenarios failed with error: `"BLOCKED: ledger_corrupt - First line is not a valid header"`

### Root Cause
Test ledger headers were missing required fields:
1. `"type": "header"` field required by hydration validation
2. Incorrect `policy_hash` ("test" instead of "phase_a_hardcoded_v1")

**Code Location**: `runtime/tests/orchestration/missions/test_loop_waiver_workflow.py:427-433, 468-474`

### Fix Applied
```python
# BEFORE (lines 427-433):
header = {
    # MISSING: "type": "header"
    "schema_version": "v1.0",
    "policy_hash": "test",  # WRONG - causes policy mismatch
    "handoff_hash": "abc",
    "run_id": waiver_context.run_id
}

# AFTER (lines 427-433):
header = {
    "type": "header",  # Added - required by ledger hydration
    "schema_version": "v1.0",
    "policy_hash": "phase_a_hardcoded_v1",  # Fixed - matches runtime
    "handoff_hash": "abc",
    "run_id": waiver_context.run_id
}
```

### Verification
- Ledger hydration now succeeds (no `LedgerIntegrityError`)
- Policy hash guard passes (no "policy_changed_mid_run" escalation)
- All 4 resume tests now PASS

**Evidence**: `pytest_test_loop_waiver_workflow.log.txt` showing 6/8 passing (resume tests included)

---

## P0.3: Deterministic Test Assertions

### Issue
2 acceptance tests used `pytest.skip()` when outcome wasn't WAIVER_REQUESTED, making tests non-deterministic.

### Root Cause
Defensive test pattern accepted both BLOCKED and WAIVER_REQUESTED outcomes due to environment uncertainty.

**Code Location**: `runtime/tests/orchestration/missions/test_loop_acceptance.py:529-534, 621-626`

### Fix Applied
```python
# BEFORE (lines 529-534):
if terminal_data["outcome"] != "WAIVER_REQUESTED":
    pytest.skip(f"Waiver workflow not triggered, got {terminal_data['outcome']}")

# AFTER (lines 529-538):
assert terminal_data["outcome"] == "WAIVER_REQUESTED", \
    f"Expected WAIVER_REQUESTED, got {terminal_data['outcome']}: {terminal_data.get('reason')}"
```

### Verification
- All assertions now strict (no conditional skips)
- Tests fail deterministically if behavior regresses
- 0 skipped tests in acceptance suite

**Evidence**: `pytest_test_loop_acceptance.log.txt` showing "20 passed, 0 skipped"

---

## Additional Fixes (Supporting)

### Test Setup Enhancements
**File**: `runtime/tests/orchestration/missions/test_loop_waiver_workflow.py`

1. **Added Missing Config Fields** (lines 73-75):
   - Added `author: "TEST"` to policy_metadata
   - Added `description` field
   - Prevents config validation errors

2. **Enhanced waiver_context Fixture** (lines 29-50):
   - Added `config/governance/protected_artefacts.json`
   - Added `docs/11_admin/BACKLOG.md` (required for debt registration)
   - Added full directory structure (docs/00_foundations, docs/01_governance)

3. **Fixed Review Packet Mocks** (lines 175-184, 296-298):
   - Added `diff_summary` field (required by PPV)
   - Added `changed_files` array (required by PPV)
   - Prevents PPV escalation during tests

---

## Test Results

### Before Fixes
```
runtime/tests/orchestration/missions/test_loop_acceptance.py:
- 18/20 passing (90%)
- 2 skipped (waiver tests)

runtime/tests/orchestration/missions/test_loop_waiver_workflow.py:
- 4/8 passing (50%)
- 2 failed (ledger_corrupt errors)
- 2 failed (waiver emission)
```

### After Fixes
```
runtime/tests/orchestration/missions/test_loop_acceptance.py:
- 20/20 passing (100%) ✅
- 0 skipped ✅

runtime/tests/orchestration/missions/test_loop_waiver_workflow.py:
- 6/8 passing (75%) ⚠️
- 2 failed (waiver emission - BLOCKED, see separate document)
```

**Net Improvement**: 22/28 → 26/28 tests passing (+4 tests, -2 skips)

---

## Files Modified

| File | Lines Changed | Purpose |
|------|---------------|---------|
| `runtime/orchestration/missions/autonomous_build_cycle.py` | 547 | Added attempt_id to waiver packet_data |
| `runtime/tests/orchestration/missions/test_loop_acceptance.py` | 529-538, 621-626 | Removed pytest.skip(), made assertions strict |
| `runtime/tests/orchestration/missions/test_loop_waiver_workflow.py` | 23-50, 73-75, 175-184, 427-433, 468-474 | Fixed ledger headers, config, context, review mocks |

**Total**: 3 files, ~50 lines changed

---

## Evidence Package

1. **Test Logs**:
   - `pytest_test_loop_acceptance.log.txt` - 20/20 passing
   - `pytest_test_loop_waiver_workflow.log.txt` - 6/8 passing, 2 emission tests blocked

2. **Code Changes**:
   - `git_diff.patch` - Full diff of all changes
   - `git_status.txt` - Modified files list

3. **Decision Document**:
   - `BLOCKED_Waiver_Workflow_Tests.md` - Analysis of 2 remaining failures with 3 options

---

## DONE Criteria Status

### Primary (Acceptance Tests)
- ✅ test_loop_acceptance.py passes 100% with 0 skips
- ✅ Waiver-request artifact exists at expected path
- ✅ No "ledger_corrupt" errors in waiver resume tests (workflow tests)
- ✅ Evidence package created

### Secondary (Waiver Workflow Tests)
- ⚠️ test_loop_waiver_workflow.py: 6/8 passing
- ⚠️ 2 emission tests blocked (redundant with acceptance tests)
- 📋 CEO decision required (see BLOCKED document)

---

## Recommendation

**APPROVE PRIMARY GOAL AS COMPLETE**

Rationale:
1. All acceptance tests pass (20/20) ✅
2. Waiver emission proven working in production code path
3. P0.1, P0.2, P0.3 all resolved
4. Test determinism achieved (0 skips)

**DEFER SECONDARY GOAL DECISION**

Options presented in `BLOCKED_Waiver_Workflow_Tests.md`:
- Option 1: Skip redundant tests (fast, low risk)
- Option 2: Deep investigation (4-8 hours, uncertain outcome)
- Option 3: Remove redundant tests (clean, requires approval)

**Next Step**: CEO to review BLOCKED document and select option.

---

## Time Investment

- P0.1 (attempt_id fix): 30 minutes
- P0.2 (ledger headers): 45 minutes
- P0.3 (remove skip): 15 minutes
- Workflow test debugging: 4+ hours (blocked on unknown mock/fixture issue)

**Total**: ~6 hours
