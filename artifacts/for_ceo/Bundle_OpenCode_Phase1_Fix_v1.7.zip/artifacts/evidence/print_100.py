
for i in range(100):
    print(f"Line {i}: Evidence capture test.")
