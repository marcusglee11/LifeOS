"""
Tests for BuildWithValidationMission v0.1
"""
import pytest
import json
import hashlib
from unittest.mock import patch, MagicMock, ANY
from pathlib import Path

from runtime.orchestration.missions.base import (
    MissionType,
    MissionContext,
    MissionValidationError,
)
from runtime.orchestration.missions.build_with_validation import BuildWithValidationMission

@pytest.fixture
def mock_context(tmp_path: Path) -> MissionContext:
    """Create a mock mission context."""
    return MissionContext(
        repo_root=tmp_path,
        baseline_commit="abc123456789",
        run_id="test-run-id",
    )

class TestBuildWithValidationMission:
    
    def test_mission_type(self):
        mission = BuildWithValidationMission()
        assert mission.mission_type == MissionType.BUILD_WITH_VALIDATION

    def test_validate_inputs_success(self):
        """Valid inputs should pass."""
        mission = BuildWithValidationMission()
        mission.validate_inputs({
            "mode": "smoke",
            "pytest_args": ["-v"]
        })

    def test_validate_inputs_fail_unknown_key(self):
        """Unknown keys should fail validation (fail-closed)."""
        mission = BuildWithValidationMission()
        with pytest.raises(MissionValidationError) as exc:
            mission.validate_inputs({"unknown_key": "value"})
        assert "Invalid inputs" in str(exc.value)

    def test_validate_inputs_fail_invalid_type(self):
        """Invalid types should fail."""
        mission = BuildWithValidationMission()
        with pytest.raises(MissionValidationError) as exc:
            mission.validate_inputs({"mode": 123})  # mode should be string

    def test_run_token_determinism(self, mock_context):
        """Verify run_token is deterministic based on params and baseline_commit."""
        mission = BuildWithValidationMission()
        inputs = {"mode": "smoke"}
        
        # We need to spy on internal logic or check output
        # Let's check output run_token
        
        # Setup mocks to allow run to complete
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="out", stderr="err")
            
            # Create pyproject.toml so SMOKE-1 passes
            (mock_context.repo_root / "pyproject.toml").touch()
            
            result1 = mission.run(mock_context, inputs)
            result2 = mission.run(mock_context, inputs)
            
            assert result1.outputs["run_token"] == result2.outputs["run_token"]
            
            # Change input -> different token
            result3 = mission.run(mock_context, {"mode": "full"})
            assert result1.outputs["run_token"] != result3.outputs["run_token"]
            
            # Change commit -> different token
            mock_context.baseline_commit = "def987"
            result4 = mission.run(mock_context, inputs)
            assert result1.outputs["run_token"] != result4.outputs["run_token"]

    def test_evidence_written_and_hash_matches(self, mock_context):
        """Verify evidence files are written and hashes match content."""
        mission = BuildWithValidationMission()
        inputs = {"mode": "smoke"}
        
        # Setup repo files
        (mock_context.repo_root / "pyproject.toml").touch()
        
        stdout_content = "smoke stdout\n"
        stderr_content = "smoke stderr"
        
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout=stdout_content,
                stderr=stderr_content
            )
            
            result = mission.run(mock_context, inputs)
            
            assert result.success is True
            evidence_dir = Path(result.outputs["evidence_dir"])
            assert evidence_dir.exists()
            
            # Verify files
            assert (evidence_dir / "smoke.stdout.txt").read_text(encoding="utf-8") == stdout_content
            assert (evidence_dir / "smoke.stderr.txt").read_text(encoding="utf-8") == stderr_content
            assert (evidence_dir / "smoke.exitcode.txt").read_text(encoding="utf-8") == "0"
            
            # Verify hashes in output matches content
            expected_stdout_sha = hashlib.sha256(stdout_content.encode("utf-8")).hexdigest()
            assert result.outputs["smoke"]["stdout_sha256"] == expected_stdout_sha

    def test_full_mode_runs_pytest(self, mock_context):
        """Verify full mode runs pytest."""
        mission = BuildWithValidationMission()
        inputs = {"mode": "full", "pytest_args": ["-x"]}
        
        (mock_context.repo_root / "pyproject.toml").touch()
        
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            
            result = mission.run(mock_context, inputs)
            
            assert result.success is True
            assert result.outputs["pytest"] is not None
            
            # Check calls
            # Expect 2 calls: compileall and pytest
            assert mock_run.call_count == 2
            
            # Verify pytest args
            args, kwargs = mock_run.call_args_list[1]
            cmd = args[0]
            assert "pytest" in str(cmd) or "pytest" in cmd
            assert "-x" in cmd

    def test_smoke_failure_fails_mission(self, mock_context):
        """Mission should fail if smoke step fails."""
        mission = BuildWithValidationMission()
        inputs = {"mode": "smoke"}
        
        (mock_context.repo_root / "pyproject.toml").touch()
        
        with patch("subprocess.run") as mock_run:
            # compileall fails
            mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="error")
            
            result = mission.run(mock_context, inputs)
            
            assert result.success is False
            assert result.outputs["smoke"]["exit_code"] == 1
