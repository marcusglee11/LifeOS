"""
Build With Validation Mission v0.1

Implements a deterministic, smoke-first build validation mission using subprocesses.
Replaces the previous Worker->Validator LLM loop implementation.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

# External dependencies (assumed present in env)
import jsonschema

from runtime.orchestration.missions.base import (
    BaseMission,
    MissionContext,
    MissionResult,
    MissionType,
    MissionValidationError,
    MissionExecutionError,
)

# Constants
SCHEMA_DIR = Path(__file__).parent / "schemas"
PARAMS_SCHEMA_FILE = SCHEMA_DIR / "build_with_validation_params_v0_1.json"
RESULT_SCHEMA_FILE = SCHEMA_DIR / "build_with_validation_result_v0_1.json"


class BuildWithValidationMission(BaseMission):
    """
    Build With Validation Mission
    
    Executes a deterministic validation sequence:
    1. Validate inputs against strict JSON schema.
    2. Compute deterministic run token.
    3. Run 'smoke' checks (compileall).
    4. Optionally run 'full' checks (pytest).
    5. Capture all outputs to evidence validation directory.
    6. Return result with cryptographic proofs.
    """

    @property
    def mission_type(self) -> MissionType:
        return MissionType.BUILD_WITH_VALIDATION

    def _load_schema(self, path: Path) -> Dict[str, Any]:
        """Load a JSON schema from disk."""
        if not path.exists():
            raise MissionExecutionError(f"Schema file not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def validate_inputs(self, inputs: Dict[str, Any]) -> None:
        """
        Validate mission inputs against the params schema.
        
        Fail-closed: raises MissionValidationError on any schema violation.
        """
        # Load schema
        try:
            schema = self._load_schema(PARAMS_SCHEMA_FILE)
        except Exception as e:
            raise MissionValidationError(f"Failed to load params schema: {e}")

        # Coerce None to empty dict (standard practice) but here we expect a dict
        if inputs is None:
            inputs = {}

        # Validate
        try:
            jsonschema.validate(instance=inputs, schema=schema)
        except jsonschema.ValidationError as e:
            raise MissionValidationError(f"Invalid inputs: {e.message}")

    def run(self, context: MissionContext, inputs: Dict[str, Any]) -> MissionResult:
        """
        Execute the mission.
        """
        # 1. Apply defaults manually to ensure we have them for canonical JSON
        # (jsonschema validation doesn't mutate the input instance with defaults automatically unless using a specific validator)
        # So we explicitly re-apply defaults matching the schema for the canonical record.
        params = inputs.copy()
        
        # Defaults from schema
        params.setdefault("mode", "smoke")
        params.setdefault("pytest_args", ["-q"])
        params.setdefault("pytest_targets", [])
        params.setdefault("capture_root_rel", "artifacts/evidence/mission_runs")

        # 2. Canonical Params & Run Token
        canonical_params_json = json.dumps(
            params, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        )
        params_calonical_sha256 = hashlib.sha256(canonical_params_json.encode("utf-8")).hexdigest()
        
        baseline_commit_norm = context.baseline_commit if context.baseline_commit else "null"
        
        token_payload = f"build_with_validation\n{baseline_commit_norm}\n{canonical_params_json}"
        run_token = hashlib.sha256(token_payload.encode("utf-8")).hexdigest()[:16]

        # 3. Setup Evidence Directory
        repo_root = context.repo_root
        capture_root = repo_root / params["capture_root_rel"]
        evidence_dir = capture_root / "build_with_validation" / run_token
        evidence_dir.mkdir(parents=True, exist_ok=True)

        # 4. SMOKE-1: pyproject.toml check
        pyproject_path = repo_root / "pyproject.toml"
        if not pyproject_path.exists():
            return self._make_result(
                success=False,
                error=f"SMOKE-1 FAILED: pyproject.toml not found in {repo_root}",
                executed_steps=["smoke:check_pyproject"],
            )

        # Helper to run subprocess and capture
        def run_proc(name: str, cmd: List[str]) -> Dict[str, Any]:
            outfile_stdout = evidence_dir / f"{name}.stdout.txt"
            outfile_stderr = evidence_dir / f"{name}.stderr.txt"
            outfile_exit = evidence_dir / f"{name}.exitcode.txt"

            try:
                proc = subprocess.run(
                    cmd, cwd=repo_root, capture_output=True, text=True
                )
                stdout = proc.stdout
                stderr = proc.stderr
                exit_code = proc.returncode
            except Exception as e:
                stdout = ""
                stderr = f"Subprocess execution failed: {e}"
                exit_code = -1

            # Write evidence
            outfile_stdout.write_text(stdout, encoding="utf-8")
            outfile_stderr.write_text(stderr, encoding="utf-8")
            outfile_exit.write_text(str(exit_code), encoding="utf-8")

            # Hash evidence
            stdout_sha = hashlib.sha256(stdout.encode("utf-8")).hexdigest()
            stderr_sha = hashlib.sha256(stderr.encode("utf-8")).hexdigest()

            return {
                "exit_code": exit_code,
                "stdout_sha256": stdout_sha,
                "stderr_sha256": stderr_sha
            }

        executed_steps = ["smoke:check_pyproject"]
        
        # 5. SMOKE-2: compileall
        # We target 'runtime' as per spec, but fail gracefully if it doesn't exist? 
        # The spec says: compileall -q runtime.
        cmd_smoke = [sys.executable, "-m", "compileall", "-q", "runtime"]
        smoke_result = run_proc("smoke", cmd_smoke)
        executed_steps.append("smoke:compileall")
        
        # 6. Full Mode: pytest
        pytest_result = None
        if params["mode"] == "full":
            pytest_args = params.get("pytest_args", ["-q"])
            pytest_targets = params.get("pytest_targets", [])
            
            # Default targets if empty
            if not pytest_targets:
                # Use robust defaults that should exist
                defaults = [
                    "runtime/tests/test_cli_mission.py",
                    "runtime/tests/test_mission_registry/test_phase3_dispatch.py"
                ]
                # Filter to only those that exist relative to repo_root
                pytest_targets = [t for t in defaults if (repo_root / t).exists()]
            
            if not pytest_targets:
                # Fallback if no specific defaults exist, maybe run all? 
                # Or just skip with warning.
                # For safety, let's just make it empty list and pytest might run nothing or everything.
                # But pytest with no args usually runs everything.
                # Spec says: "default to: ... if empty"
                pass 

            cmd_pytest = [sys.executable, "-m", "pytest"] + pytest_args + pytest_targets
            pytest_result = run_proc("pytest", cmd_pytest)
            executed_steps.append("full:pytest")

        # 7. Construct Result
        outputs = {
            "run_token": run_token,
            "repo_root": str(repo_root),
            "baseline_commit": context.baseline_commit, # Nullable allowed by schema
            "params_canonical_sha256": params_calonical_sha256,
            "smoke": smoke_result,
            "pytest": pytest_result,
            "evidence_dir": str(evidence_dir),
        }
        
        # 8. Validate Result
        try:
            result_schema = self._load_schema(RESULT_SCHEMA_FILE)
            jsonschema.validate(instance=outputs, schema=result_schema)
        except Exception as e:
            return self._make_result(
                success=False,
                error=f"Result schema validation failed: {e}",
                executed_steps=executed_steps,
                outputs=outputs # Return outputs anyway for debugging
            )

        # 9. Determine Success
        # Success if smoke passed (0) AND (if full mode) pytest passed (0)
        success = (smoke_result["exit_code"] == 0)
        if params["mode"] == "full" and pytest_result:
             success = success and (pytest_result["exit_code"] == 0)

        return self._make_result(
            success=success,
            outputs=outputs,
            executed_steps=executed_steps,
            evidence={
                "run_token": run_token,
                "evidence_path": str(evidence_dir)
            }
        )
