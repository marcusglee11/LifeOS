
import pytest
import os
import sys

# Add scripts/ to path
scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
sys.path.append(scripts_dir)

import opencode_gate_policy as policy
from opencode_gate_policy import ReasonCode, MODE_STEWARD, MODE_BUILDER

class TestOpencodebuilderPolicy:

    def test_steward_mode_regression(self):
        """Verify Steward mode still behaves strictly."""
        # Blocked: .py in runtime
        allowed, reason = policy.validate_operation("A", "runtime/foo.py", mode=MODE_STEWARD)
        assert allowed is False
        assert reason == ReasonCode.DENYLIST_EXT_BLOCKED # Matches denylist (ext) before allowlist check

        # Allowed: .md in docs/
        allowed, reason = policy.validate_operation("A", "docs/test.md", mode=MODE_STEWARD)
        assert allowed is True

    def test_builder_mode_allowlist(self):
        """Verify Builder mode allows code in authorized roots."""
        roots = ["runtime/", "tests/"]
        for root in roots:
            path = f"{root}test_file.py"
            allowed, reason = policy.validate_operation("A", path, mode=MODE_BUILDER)
            assert allowed is True, f"Builder should allow {path}"
            assert reason is None

    def test_builder_mode_blocks_scripts(self):
        """Verify Builder mode does NOT allow arbitrary scripts writes."""
        path = "scripts/malicious.py"
        allowed, reason = policy.validate_operation("A", path, mode=MODE_BUILDER)
        assert allowed is False
        assert reason == ReasonCode.BUILDER_OUTSIDE_ALLOWLIST

    def test_builder_mode_blocks_critical_files(self):
        """Verify Critical Enforcement Files are blocked even in Builder mode."""
        
        critical_files = [
            "scripts/opencode_gate_policy.py",
            "scripts/opencode_ci_runner.py",
            "docs/01_governance/OpenCode_First_Stewardship_Policy_v1.1.md"
        ]
        
        for path in critical_files:
            allowed, reason = policy.validate_operation("M", path, mode=MODE_BUILDER)
            assert allowed is False, f"Critical file {path} should be blocked"
            assert reason == ReasonCode.CRITICAL_FILE_BLOCKED

    def test_builder_mode_blocks_governance(self):
        """Verify Builder cannot touch governance outside of critical list too."""
        # Governance roots are not in allowlist, so should be blocked by default.
        path = "docs/01_governance/new_ruling.md"
        allowed, reason = policy.validate_operation("A", path, mode=MODE_BUILDER)
        assert allowed is False
        assert reason == ReasonCode.BUILDER_OUTSIDE_ALLOWLIST

    def test_rename_logic_implicit(self):
        """Verify rename logic (old path check) works via double call pattern."""
        # Rename critical file -> safe name
        old_path = "scripts/opencode_gate_policy.py"
        new_path = "runtime/safe.py"
        
        # New path check (A)
        allowed_new, _ = policy.validate_operation("R", new_path, mode=MODE_BUILDER)
        assert allowed_new is True # Destination is valid
        
        # Old path check (D)
        allowed_old, reason_old = policy.validate_operation("D", old_path, mode=MODE_BUILDER)
        assert allowed_old is False
        assert reason_old == ReasonCode.CRITICAL_FILE_BLOCKED
