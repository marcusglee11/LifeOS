import pytest
import json
import hashlib
from unittest.mock import MagicMock, patch
from pathlib import Path
from runtime.orchestration.missions.build_with_validation import BuildWithValidationMission
from runtime.orchestration.missions.base import MissionContext, MissionValidationError

@pytest.fixture
def mission():
    return BuildWithValidationMission()

@pytest.fixture
def context(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    return MissionContext(
        repo_root=repo,
        baseline_commit="test_commit",
        run_id="test_run",
        metadata={}
    )

def test_mission_type(mission):
    assert mission.mission_type == "build_with_validation"

def test_validate_inputs_valid(mission):
    valid_inputs = {
        "mode": "smoke",
        "pytest_args": ["-v"],
        "pytest_targets": ["foo"]
    }
    # Should not raise
    mission.validate_inputs(valid_inputs)

def test_validate_inputs_invalid_key(mission):
    with pytest.raises(Exception):
        mission.validate_inputs({"invalid_key": "val"})

def test_validate_inputs_invalid_type(mission):
    with pytest.raises(Exception):
        mission.validate_inputs({"mode": 123})

def test_run_determinism(mission, context):
    """Test that run_token is deterministic based on params and commit. Uses real FS."""
    inputs = {"mode": "smoke"}
    
    # Mock subprocess only
    mock_res = MagicMock(returncode=0, stdout=b"OK", stderr=b"")
    
    with patch("subprocess.run", return_value=mock_res):
        
        res1 = mission.run(context, inputs)
        assert res1.success, f"Run 1 failed: {res1.error}"
        
        res2 = mission.run(context, inputs)
        assert res2.success, f"Run 2 failed: {res2.error}"
        
        assert res1.outputs["run_token"] == res2.outputs["run_token"]
        assert res1.outputs["repo_root"] == str(context.repo_root)
        
        # Explicit defaults
        explicit_defaults = {
            "mode": "smoke",
            "pytest_args": ["-q"],
            "pytest_targets": [],
            "capture_root_rel": "artifacts/evidence/mission_runs"
        }
        res3 = mission.run(context, explicit_defaults)
        assert res3.success
        assert res1.outputs["run_token"] == res3.outputs["run_token"]

def test_run_evidence_capture(mission, context):
    """Test evidence files are written and hashes computed. Uses real FS."""
    inputs = {"mode": "smoke"}
    
    # Mock return values
    mock_sub_res = MagicMock(returncode=0, stdout=b"OUT", stderr=b"ERR")
    
    with patch("subprocess.run", return_value=mock_sub_res):
        
        res = mission.run(context, inputs)
        
        assert res.success
        assert res.outputs["smoke"]["exit_code"] == 0
        assert res.outputs["smoke"]["stdout_sha256"] == hashlib.sha256(b"OUT").hexdigest()
        assert res.outputs["smoke"]["stderr_sha256"] == hashlib.sha256(b"ERR").hexdigest()
        
        # Verify files written to disk
        evidence_path = Path(res.outputs["evidence_dir"])
        assert evidence_path.exists()
        assert (evidence_path / "smoke_compile.stdout").read_bytes() == b"OUT"
        assert (evidence_path / "smoke_compile.stderr").read_bytes() == b"ERR"

def test_run_full_mode_trigger(mission, context):
    """Test full mode triggers pytest."""
    inputs = {"mode": "full", "pytest_targets": ["tests/"]}
    
    mock_sub_res = MagicMock(returncode=0, stdout=b"", stderr=b"")
    
    with patch("subprocess.run", return_value=mock_sub_res):
         
        res = mission.run(context, inputs)
        assert res.success
        
        assert "full:pytest" in res.executed_steps
        assert res.outputs["pytest"] is not None

def test_run_failure_propagation(mission, context):
    """Test failure in smoke stops execution."""
    inputs = {"mode": "full", "pytest_targets": ["tests/"]}
    
    # Smoke fails
    mock_sub_res = MagicMock(returncode=1, stdout=b"", stderr=b"FAIL")
    
    with patch("subprocess.run", return_value=mock_sub_res):
        
        res = mission.run(context, inputs)
        
        assert not res.success
        assert "full:pytest" not in res.executed_steps
        assert res.outputs["smoke"]["exit_code"] == 1

def test_full_mode_fail_closed(mission, context):
    """P0.4: Fail closed if no targets provided in full mode."""
    inputs = {"mode": "full", "pytest_targets": []}
    
    # Smoke passes
    mock_sub_res = MagicMock(returncode=0, stdout=b"", stderr=b"")
    
    with patch("subprocess.run", return_value=mock_sub_res):
         
        res = mission.run(context, inputs)
        
        assert not res.success
        assert "Full mode requires explicit pytest_targets" in res.error

def test_full_mode_default_subset(mission, context):
    """P0.4: Safe default subset behavior."""
    inputs = {"mode": "full", "pytest_targets": []}
    
    # Mock smoke passing, pytest passing
    mock_smoke = MagicMock(returncode=0, stdout=b"OK", stderr=b"")
    mock_pytest = MagicMock(returncode=0, stdout=b"Pytest OK", stderr=b"")
    
    # We need to mock subprocess.run to return smoke first, then pytest
    # But side_effect list is simpler
    
    with patch("subprocess.run", side_effect=[mock_smoke, mock_pytest]),          patch("pathlib.Path.exists", return_value=True): # Mock file exists
         
        res = mission.run(context, inputs)
        
        assert res.success
        assert "full:pytest" in res.executed_steps
        assert res.outputs["pytest"] is not None
