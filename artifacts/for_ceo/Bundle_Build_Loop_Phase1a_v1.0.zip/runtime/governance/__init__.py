# runtime/governance/__init__.py
"""
Runtime Governance Package.
Provides protected artefact enforcement and autonomy ceilings.
"""
