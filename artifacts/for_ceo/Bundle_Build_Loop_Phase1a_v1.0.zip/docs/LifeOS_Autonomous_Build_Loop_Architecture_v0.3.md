# LifeOS Autonomous Build Loop Architecture v0.3 — DEPRECATED LOCATION

> [!CAUTION]
> **This file is a deprecation stub.**
> The canonical location is: `docs/03_runtime/LifeOS_Autonomous_Build_Loop_Architecture_v0.3.md`

---

This file previously contained the Autonomous Build Loop Architecture v0.3 specification.

**Canonical Path:** `docs/03_runtime/LifeOS_Autonomous_Build_Loop_Architecture_v0.3.md`

**Reason for Relocation:** Runtime specifications belong under `docs/03_runtime/` per repository conventions.

Please update any references to point to the canonical location.
