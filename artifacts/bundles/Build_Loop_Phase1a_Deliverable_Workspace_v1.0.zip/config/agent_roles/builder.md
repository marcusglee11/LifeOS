# Role Prompt (Scaffold Stub)

Status: scaffold-only.
Authority: governance surface (Council ruling required to modify once baselined).

This file is intentionally minimal for Phase 1a scaffold validation.
