# Governance Baseline — Initial Review Packet v1.0

- baseline_path: config/governance_baseline.yaml
- baseline_sha256: 2b1fdc2a43cce87fb3b8b891567a15c68ef57df08c457cae0d15b71728aa3ce8
- approver: CEO
- council_ruling_ref: docs/01_governance/Council_Ruling_Build_Loop_Architecture_v1.0.md

## Governance Surfaces Included

- `CLAUDE.md`
- `GEMINI.md`
- `config/agent_roles/designer.md`
- `config/agent_roles/builder.md`
- `config/agent_roles/steward.md`
- `config/agent_roles/cso.md`
- `config/agent_roles/reviewer_architect.md`
- `config/agent_roles/reviewer_alignment.md`
- `config/agent_roles/reviewer_risk.md`
- `config/agent_roles/reviewer_governance.md`
- `config/models.yaml`
- `docs/00_foundations/README.md`
- `docs/01_governance/Council_Ruling_Build_Loop_Architecture_v1.0.md`
- `docs/03_runtime/LifeOS_Autonomous_Build_Loop_Architecture_v0.3.md`
- `runtime/orchestration/transforms/__init__.py`
- `scripts/opencode_gate_policy.py`
