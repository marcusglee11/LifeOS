# Agent Constitution (Scaffold Stub)

Status: scaffold-only.
