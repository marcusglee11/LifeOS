"""Envelope Policy (Scaffold Stub)

Phase 1a scaffold: placeholder policy surface.
Once baselined, modifications require Council ruling per Build Loop Architecture v0.3.
"""

def policy_version() -> str:
    return "scaffold-v1"
