This directory contains files included for context/reference only.
These files are NOT part of the patch delta and strictly SHOULD NOT be applied.