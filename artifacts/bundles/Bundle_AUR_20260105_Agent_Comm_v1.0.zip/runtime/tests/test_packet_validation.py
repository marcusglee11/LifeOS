
import pytest
import subprocess
import os
import uuid
import yaml
from datetime import datetime, timezone, timedelta

VALIDATOR_SCRIPT = "scripts/validate_packet.py"

def run_validator(path, ignore_skew=True):
    cmd = ["python", VALIDATOR_SCRIPT, path]
    if ignore_skew:
        cmd.append("--ignore-skew")
    print(f"Running: {' '.join(cmd)}")  # Add this for debugging
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr

@pytest.fixture
def base_envelope():
    return {
        "packet_id": str(uuid.uuid4()),
        "packet_type": "HANDOFF_PACKET", # Default
        "schema_version": "1.1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_agent": "TestSrc",
        "target_agent": "TestDst",
        "chain_id": str(uuid.uuid4()),
        "priority": "P2_NORMAL",
        "nonce": str(uuid.uuid4()),
        "ttl_hours": 72
    }

def test_valid_handoff_packet(tmp_path, base_envelope):
    data = base_envelope.copy()
    data["packet_type"] = "HANDOFF_PACKET"
    data.update({
        "reason": "TASK_COMPLETE",
        "current_state_summary": "Done",
        "next_step_goal": "Review",
        "knowledge_transfer": "None",
        "attachments": []
    })
    
    p = tmp_path / "valid_handoff.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 0, f"Validation failed: {stderr}"

def test_valid_council_review_markdown(tmp_path, base_envelope):
    data = base_envelope.copy()
    data["packet_type"] = "COUNCIL_REVIEW_PACKET"
    data.update({
        "review_type": "CODE",
        "subject_ref": "foo.py",
        "subject_summary": "Fix",
        "objective": "Approve",
        "context_refs": [],
        "urgency_rationale": "High"
    })
    
    content = f"---\n{yaml.dump(data)}---\n# Some Markdown Content"
    p = tmp_path / "valid_crp.md"
    p.write_text(content, encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 0

def test_unknown_field_rejection(tmp_path, base_envelope):
    data = base_envelope.copy()
    data["packet_type"] = "HANDOFF_PACKET"
    data.update({
        "reason": "TASK_COMPLETE",
        "current_state_summary": "Done",
        "next_step_goal": "Review",
        "knowledge_transfer": "None",
        "attachments": []
    })
    # Add Unknown Field
    data["UNKNOWN_FIELD_XYZ"] = "Bad"
    
    p = tmp_path / "unknown_field.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 2 # EXIT_SCHEMA_VIOLATION
    assert "Unknown fields" in err

def test_missing_envelope_field(tmp_path, base_envelope):
    data = base_envelope.copy()
    del data["packet_id"] # Missing required
    
    p = tmp_path / "missing_env.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 2
    assert "Missing required envelope field" in err

def test_lineage_violation(tmp_path, base_envelope):
    data = base_envelope.copy()
    data["packet_type"] = "COUNCIL_APPROVAL_PACKET"
    data.update({
        "verdict": "APPROVED",
        # Missing review_packet_id
        "subject_hash": "abc",
        "rationale": "Good",
        "conditions": [],
        "blocking_issues": [],
        "votes": {}
    })
    
    p = tmp_path / "lineage_fail.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 4 # EXIT_LINEAGE_VIOLATION
    assert "missing review_packet_id" in err

def test_payload_size_limit(tmp_path, base_envelope):
    data = base_envelope.copy()
    data["packet_type"] = "HANDOFF_PACKET"
    data.update({
        "reason": "TASK_COMPLETE",
        "current_state_summary": "x" * (8192 * 1024 + 100), # Exceed 8MB
        "next_step_goal": "Review",
        "knowledge_transfer": "None",
        "attachments": []
    })
    
    p = tmp_path / "oversize.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 3 # EXIT_SECURITY_VIOLATION
    assert "limit" in err

def test_type_violation(tmp_path, base_envelope):
    data = base_envelope.copy()
    data["ttl_hours"] = "NOT_INT" # Type mismatch
    
    p = tmp_path / "type_fail.yaml"
    p.write_text(yaml.dump(data), encoding='utf-8')
    
    code, out, err = run_validator(str(p))
    assert code == 2
    assert "must be integer" in err
