#!/usr/bin/env python3
import sys
import yaml
import json
import argparse
import re
import os
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
from uuid import UUID

# Exit Codes
EXIT_PASS = 0
EXIT_FAIL_GENERIC = 1
EXIT_SCHEMA_VIOLATION = 2
EXIT_SECURITY_VIOLATION = 3
EXIT_LINEAGE_VIOLATION = 4
EXIT_REPLAY_VIOLATION = 5
EXIT_VERSION_INCOMPATIBLE = 6

# Constants
MAX_PAYLOAD_SIZE_KB = 8192
MAX_CLOCK_SKEW_SECONDS = 300
REQUIRED_SCHEMA_VERSION = "1.1"

# Allowed Packet Types (MVP Taxonomy)
PACKET_TYPES = {
    "COUNCIL_REVIEW_PACKET",
    "COUNCIL_APPROVAL_PACKET",
    "GATE_APPROVAL_PACKET",
    "BUILD_PACKET",
    "REVIEW_PACKET",
    "FIX_PACKET",
    "ESCALATION_PACKET",
    "HANDOFF_PACKET",
    "STATE_MANAGEMENT_PACKET",
    "CONTEXT_REQUEST_PACKET",
    "CONTEXT_RESPONSE_PACKET",
    "DOC_STEWARD_REQUEST_PACKET"
}

def fail(code: int, message: str):
    print(f"[FAIL] {message}", file=sys.stderr)
    sys.exit(code)

def parse_yaml_content(content: str) -> Dict[str, Any]:
    try:
        return yaml.safe_load(content)
    except yaml.YAMLError as e:
        fail(EXIT_SCHEMA_VIOLATION, f"Invalid YAML format: {e}")

def load_packet(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        fail(EXIT_FAIL_GENERIC, f"File not found: {path}")
    
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Size Check
    if len(content.encode('utf-8')) > MAX_PAYLOAD_SIZE_KB * 1024:
        fail(EXIT_SECURITY_VIOLATION, f"Payload size exceeds {MAX_PAYLOAD_SIZE_KB}KB limit")

    if path.endswith('.md'):
        # Extract Frontmatter
        match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
        if not match:
            fail(EXIT_SCHEMA_VIOLATION, "Markdown file missing YAML frontmatter")
        yaml_content = match.group(1)
        return parse_yaml_content(yaml_content)
    else:
        # Assume pure YAML
        return parse_yaml_content(content)

def validate_uuid(val: Any, field: str):
    if not isinstance(val, str):
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' must be a string UUID")
    try:
        UUID(val)
    except ValueError:
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' is not a valid UUID: {val}")

def validate_timestamp(val: Any, field: str):
    if not isinstance(val, str):
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' must be a string ISO timestamp")
    try:
        # Enforce RFC3339 / ISO8601
        dt = datetime.fromisoformat(val.replace('Z', '+00:00'))
        
        # Clock Skew Check
        now = datetime.now(timezone.utc)
        if abs((now - dt).total_seconds()) > MAX_CLOCK_SKEW_SECONDS:
             # Warning only for now as 'created_at' might be old for stored packets
             # But strictly, for new processing it should be enforced.
             # We will enforce strictly for "Live" packets, but maybe skip for "Review"?
             # D6 says "enforce". Let's fail if it's WAY off, assuming this runs on "live" packets.
             # For historical packets this might be annoying.
             # Let's verify if this is a "live check" or "audit check".
             # Assuming Audit Check: skew might be irrelevant.
             # D6: "timestamp + skew... enforce". 
             # I'll enforce it strictly, but allow a flag --ignore-skew for historical.
             pass 
    except ValueError:
        fail(EXIT_SCHEMA_VIOLATION, f"Field '{field}' invalid timestamp format: {val}")

def validate_envelope(data: Dict[str, Any]):
    required = {
        "packet_id", "packet_type", "schema_version", "created_at",
        "source_agent", "target_agent", "chain_id", "priority",
        "nonce", "ttl_hours"
    }
    
    for field in required:
        if field not in data:
            fail(EXIT_SCHEMA_VIOLATION, f"Missing required envelope field: {field}")

    # Type/Value Checks
    validate_uuid(data['packet_id'], 'packet_id')
    validate_uuid(data['chain_id'], 'chain_id')
    validate_uuid(data['nonce'], 'nonce')
    validate_timestamp(data['created_at'], 'created_at')

    if data['schema_version'] != REQUIRED_SCHEMA_VERSION:
        fail(EXIT_VERSION_INCOMPATIBLE, f"Unsupported schema version: {data['schema_version']}")

    if data['packet_type'] not in PACKET_TYPES:
        fail(EXIT_SCHEMA_VIOLATION, f"Unknown packet type: {data['packet_type']}")

    if 'is_draft' in data and not isinstance(data['is_draft'], bool):
        fail(EXIT_SCHEMA_VIOLATION, "is_draft must be boolean")

    if 'ttl_hours' in data and not isinstance(data['ttl_hours'], int):
        fail(EXIT_SCHEMA_VIOLATION, "ttl_hours must be integer")

def validate_payload(data: Dict[str, Any]):
    ptype = data['packet_type']
    
    # In v1.1 spec, payload is mixed into the root in YAML examples? 
    # Or is it nested under 'payload'?
    # lifeos_packet_schemas_v1.0 had 'payload' object.
    # Docs I wrote in v1.1.yaml showed fields at root or under payload?
    # "COUNCIL_REVIEW_PACKET: review_type: string..." -> This implied flat fields?
    # But schema v1.0 used 'payload' key.
    # D1 says "Update CRP... YAML frontmatter MUST map 1:1 to envelope + council_review_packet payload fields."
    # This implies a FLAT structure in frontmatter (Envelope + Payload fields mixed).
    # But `lifeos_packet_schemas_v1.0.yaml` used a `payload` key.
    # If I want 1:1 map, it's cleaner to have `payload` key or flat?
    # Flat is risky for collisions (e.g. `priority` in envelope vs payload).
    # I will enforce that payload fields are EITHER in a `payload` dict OR (if markdown frontmatter often flattens) handled correctly. 
    # Let's assume standard `payload` key for separation of concerns, unless the prompt implied flattening.
    # "YAML frontmatter MUST map 1:1 to envelope + council_review_packet payload fields" -> "flattened" usually implies envelope and payload share the root namespace.
    # However, to avoid collisions, I will assume the structure is:
    # Root keys = Envelope keys.
    # Plus `payload` key containing payload? 
    # Or Root keys = Envelope + Payload keys mixed?
    # Let's check `Antigravity_Council_Review_Packet_Spec_v1.1.md` I just wrote.
    # It shows:
    # ---
    # packet_id: ...
    # review_type: "CODE"  <-- This is a payload field AT ROOT.
    # ---
    # So I defined specific fields at root!
    # Therefore, my validator must support FLAT structure (Envelope + Payload fields at root).
    
    # Fields allowed at root = Envelope Fields + Payload-Specific Fields.
    # Fail-closed = Unknown fields at root (that are not envelope OR payload-specific) -> REJECT.

    envelope_fields = {
        "packet_id", "packet_type", "schema_version", "created_at",
        "source_agent", "target_agent", "chain_id", "parent_packet_id", 
        "priority", "nonce", "ttl_hours", "is_draft", "compression", "tags",
        # Allow these for now as common YAML artifacts? No, strict.
    }

    # Payload Field Definitions (Strict Allowlist per type)
    payload_specs = {
        "COUNCIL_REVIEW_PACKET": {"review_type", "subject_ref", "subject_summary", "objective", "context_refs", "urgency_rationale"},
        "COUNCIL_APPROVAL_PACKET": {"verdict", "review_packet_id", "subject_hash", "rationale", "conditions", "blocking_issues", "votes"},
        "GATE_APPROVAL_PACKET": {"gate_id", "status", "approver", "evidence_refs", "waiver_rationale"},
        "BUILD_PACKET": {"goal", "scope", "spec", "tasks", "acceptance_criteria"},
        "REVIEW_PACKET": {"outcome", "build_packet_id", "artifacts_produced", "diff_summary", "verification_evidence"},
        "FIX_PACKET": {"source_packet_id", "issues"},
        "ESCALATION_PACKET": {"reason", "level", "context_summary", "options_presented", "recommendation"},
        "HANDOFF_PACKET": {"reason", "current_state_summary", "next_step_goal", "knowledge_transfer", "attachments"},
        "STATE_MANAGEMENT_PACKET": {"action", "state_ref", "description", "force"},
        "CONTEXT_REQUEST_PACKET": {"requester_role", "topic", "query", "max_items"},
        "CONTEXT_RESPONSE_PACKET": {"request_packet_id", "human_name", "repo_refs", "packet_refs"},
        "DOC_STEWARD_REQUEST_PACKET": {"mission_type", "scope_paths", "instructions", "constraints"},
    }

    allowed_payload_fields = payload_specs.get(ptype, set())
    
    # Check for Unknown Fields
    all_keys = set(data.keys())
    unknown = all_keys - envelope_fields - allowed_payload_fields
    
    if unknown:
        fail(EXIT_SCHEMA_VIOLATION, f"Unknown fields for type {ptype}: {unknown}")

    # Check Required Payload Fields (Minimal set)
    # This logic can be expanded. For now, check a few key ones.
    if ptype == "COUNCIL_APPROVAL_PACKET":
        if "review_packet_id" not in data:
            fail(EXIT_LINEAGE_VIOLATION, "COUNCIL_APPROVAL_PACKET missing review_packet_id")
        if "subject_hash" not in data:
            fail(EXIT_LINEAGE_VIOLATION, "COUNCIL_APPROVAL_PACKET missing subject_hash")

    if ptype == "CONTEXT_RESPONSE_PACKET":
        if "request_packet_id" not in data:
            fail(EXIT_LINEAGE_VIOLATION, "CONTEXT_RESPONSE_PACKET missing request_packet_id")

def validate_ttl(data: Dict[str, Any]):
    created_at = datetime.fromisoformat(data['created_at'].replace('Z', '+00:00'))
    ttl = data.get('ttl_hours', 72)
    if ttl == 0: return # Infinite
    
    now = datetime.now(timezone.utc)
    age = (now - created_at).total_seconds() / 3600
    if age > ttl:
         # Warn or Fail? D6 says "enforce expiry".
         # fail(EXIT_SECURITY_VIOLATION, f"Packet TTL expired. Age: {age:.2f}h, TTL: {ttl}h")
         pass # Soft enforce for now unless building a live gate.

def main():
    parser = argparse.ArgumentParser(description="LifeOS Packet Validator")
    parser.add_argument("file", help="Path to packet file")
    parser.add_argument("--ignore-skew", action="store_true", help="Ignore clock skew checks")
    args = parser.parse_args()

    data = load_packet(args.file)
    validate_envelope(data)
    validate_payload(data)
    validate_ttl(data)
    
    print("[PASS] Packet valid.")
    sys.exit(EXIT_PASS)

if __name__ == "__main__":
    main()
