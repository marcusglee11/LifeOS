#!/usr/bin/env python3
"""
OpenCode Steward Certification Harness (v1.3)
==============================================

Tests the hardened opencode_ci_runner.py enforcement layer.
Runs in isolation (worktree) and verifies security boundaries.
"""

import os
import sys
import subprocess
import time
import re
import json
import argparse
import shutil
import tempfile
from datetime import datetime

# Configuration
EVIDENCE_DIR = "artifacts/evidence/opencode_steward_certification"
RUNNER_SCRIPT = "scripts/opencode_ci_runner.py"
PORT = 62585

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def run_command(cmd, cwd=None, capture=True):
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=capture, text=True, encoding='utf-8')
    return result

def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def make_json_task(files, action, instruction):
    """Create JSON-structured task for the hardened runner."""
    return json.dumps({"files": files, "action": action, "instruction": instruction})

class TestRunner:
    def __init__(self, port, repo_root):
        self.port = port
        self.repo_root = repo_root
        self.results = []
        ensure_dir(os.path.join(repo_root, EVIDENCE_DIR))
        
    def run_runner(self, task_json, expect_fail=False, override_foundations=False):
        """Run the hardened CI runner with JSON task."""
        # Use double quotes and escape internal quotes for Windows compatibility
        escaped_task = task_json.replace('"', '\\"')
        cmd = f'python {RUNNER_SCRIPT} --port {self.port} --task "{escaped_task}"'
        if override_foundations:
            cmd += ' --override-foundations'
        
        log(f"Running: {task_json[:80]}...")
        result = run_command(cmd, cwd=self.repo_root)
        
        if expect_fail:
            success = result.returncode != 0
            if not success:
                log(f"Expected FAIL but got SUCCESS")
        else:
            success = result.returncode == 0
            if not success:
                log(f"Expected SUCCESS but got FAIL: {result.stderr}")
        
        return result, success

    def record_result(self, test_id, name, success, details=""):
        status = "PASS" if success else "FAIL"
        log(f"Test {test_id}: {name} -> {status} {details}")
        self.results.append({
            "id": test_id,
            "name": name,
            "status": status,
            "details": details,
            "timestamp": datetime.now().isoformat()
        })

    def report(self):
        log("\n--- TEST SUMMARY ---")
        passed = sum(1 for r in self.results if r['status'] == 'PASS')
        total = len(self.results)
        for r in self.results:
            print(f"{r['id']}: {r['status']} - {r['name']}")
        print(f"\nTotal: {total}, Passed: {passed}, Failed: {total - passed}")
        
        report_path = os.path.join(self.repo_root, EVIDENCE_DIR, "CERTIFICATION_REPORT_v1_3.json")
        with open(report_path, 'w') as f:
            json.dump({
                "suite_version": "1.3",
                "timestamp": datetime.now().isoformat(),
                "total": total,
                "passed": passed,
                "failed": total - passed,
                "results": self.results
            }, f, indent=2)
        log(f"Report saved to {report_path}")

    # ========================================================================
    # PHASE A: Core Stewardship (JSON-based)
    # ========================================================================
    def test_input_json_valid(self):
        """T-INPUT-1: Valid JSON task accepted."""
        task = make_json_task(["docs/internal/test.md"], "create", "Create a test file.")
        _, success = self.run_runner(task, expect_fail=False)
        self.record_result("T-INPUT-1", "Valid JSON Accepted", success)

    def test_input_freetext_rejected(self):
        """T-INPUT-2: Free-text task rejected."""
        # Pass raw text (not JSON)
        cmd = f'python {RUNNER_SCRIPT} --port {self.port} --task "Please update the docs"'
        result = run_command(cmd, cwd=self.repo_root)
        success = result.returncode != 0  # Should fail
        self.record_result("T-INPUT-2", "Free-Text Rejected", success)

    # ========================================================================
    # PHASE B: Security Tests
    # ========================================================================
    def test_path_traversal_rejected(self):
        """T-SEC-1: Path traversal rejected."""
        task = make_json_task(["docs/../secrets.txt"], "modify", "Attempt traversal.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-1", "Path Traversal Rejected", success)

    def test_absolute_path_rejected(self):
        """T-SEC-2: Absolute path rejected."""
        task = make_json_task(["C:/Windows/System32/test.txt"], "create", "Attempt absolute.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-2", "Absolute Path Rejected", success)

    def test_denylist_py_file(self):
        """T-SEC-3: Modify *.py file rejected."""
        task = make_json_task(["docs/example.py"], "modify", "Attempt py edit.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-3", "Denylist *.py Rejected", success)

    def test_denylist_scripts(self):
        """T-SEC-4: Modify scripts/** rejected."""
        task = make_json_task(["scripts/test.md"], "modify", "Attempt scripts edit.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-4", "Denylist scripts/** Rejected", success)

    def test_denylist_config(self):
        """T-SEC-5: Any operation on config/** rejected."""
        task = make_json_task(["config/settings.yaml"], "create", "Attempt config.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-5", "Denylist config/** Rejected", success)

    def test_denylist_gemini_md(self):
        """T-SEC-6: Modify GEMINI.md rejected."""
        task = make_json_task(["GEMINI.md"], "modify", "Attempt GEMINI edit.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-6", "Denylist GEMINI.md Rejected", success)

    def test_denylist_foundations_no_override(self):
        """T-SEC-7: Modify docs/00_foundations/** without override rejected."""
        task = make_json_task(["docs/00_foundations/LifeOS_Constitution_v2.0.md"], "modify", "Attempt Constitution edit.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-7", "Denylist Foundations Rejected", success)

    def test_evidence_readonly(self):
        """T-SEC-8: Write to artifacts/evidence/** rejected."""
        task = make_json_task(["artifacts/evidence/test.json"], "create", "Attempt evidence write.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-8", "Evidence Read-Only Enforced", success)

    def test_outside_allowed_roots(self):
        """T-SEC-9: Path outside allowed roots rejected."""
        task = make_json_task(["runtime/core.py"], "modify", "Attempt runtime edit.")
        _, success = self.run_runner(task, expect_fail=True)
        self.record_result("T-SEC-9", "Outside Allowed Roots Rejected", success)

    # ========================================================================
    # PHASE C: Git State Tests
    # ========================================================================
    def test_clean_tree_start(self):
        """T-GIT-1: Working tree clean at start (ignoring untracked)."""
        result = run_command("git status --porcelain", cwd=self.repo_root)
        lines = result.stdout.strip().splitlines()
        dirty = [l for l in lines if not l.startswith("??")]
        success = len(dirty) == 0
        self.record_result("T-GIT-1", "Clean Tree Start", success, f"Dirty: {dirty[:3]}")

    # ========================================================================
    # RUN PHASES
    # ========================================================================
    def run_phase_a(self):
        log("--- RUNNING PHASE A: Input Validation ---")
        self.test_input_json_valid()
        self.test_input_freetext_rejected()

    def run_phase_b(self):
        log("--- RUNNING PHASE B: Security Tests ---")
        self.test_path_traversal_rejected()
        self.test_absolute_path_rejected()
        self.test_denylist_py_file()
        self.test_denylist_scripts()
        self.test_denylist_config()
        self.test_denylist_gemini_md()
        self.test_denylist_foundations_no_override()
        self.test_evidence_readonly()
        self.test_outside_allowed_roots()

    def run_phase_c(self):
        log("--- RUNNING PHASE C: Git State ---")
        self.test_clean_tree_start()

    def run_all(self):
        self.run_phase_a()
        self.run_phase_b()
        self.run_phase_c()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="OpenCode Steward Certification Harness v1.3")
    parser.add_argument("--port", type=int, default=62585)
    parser.add_argument("--phase", type=str, default="ALL", choices=["A", "B", "C", "ALL"])
    args = parser.parse_args()
    
    repo_root = os.getcwd()
    runner = TestRunner(args.port, repo_root)
    
    if args.phase == "A":
        runner.run_phase_a()
    elif args.phase == "B":
        runner.run_phase_b()
    elif args.phase == "C":
        runner.run_phase_c()
    else:
        runner.run_all()
    
    runner.report()
