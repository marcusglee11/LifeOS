#!/usr/bin/env python3
"""
Doc Steward Delegation Orchestrator
====================================

Thin orchestrator shim for delegating doc stewardship tasks to DOC_STEWARD role.
This is temporary scaffolding that retires when COO control plane is implemented.

Usage:
    python delegate_to_doc_steward.py --mission INDEX_UPDATE [--dry-run] [--case-id UUID]
"""

import argparse
import json
import os
import sys
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import hashlib

# Add runtime to path for verifier import
sys.path.insert(0, str(Path(__file__).parent.parent / "runtime"))

try:
    import requests
except ImportError:
    print("ERROR: requests library required. Install with: pip install requests")
    sys.exit(1)


# === Configuration ===
OPENCODE_URL = os.environ.get("OPENCODE_URL", "http://127.0.0.1:4096")
OPENCODE_MODEL = os.environ.get("OPENCODE_MODEL", "google/gemini-2.0-flash-001")
LEDGER_DIR = Path(__file__).parent.parent / "artifacts" / "ledger" / "dl_doc"
DOCS_DIR = Path(__file__).parent.parent / "docs"


# === Packet Dataclasses ===
@dataclass
class DocStewardRequest:
    """DOC_STEWARD_REQUEST packet per North-Star Operating Model v0.5"""
    packet_id: str
    packet_type: str = "DOC_STEWARD_REQUEST"
    case_id: str = ""
    mission_type: str = ""  # INDEX_UPDATE | CORPUS_REGEN | DOC_MOVE
    files_to_steward: list = field(default_factory=list)
    constraints: dict = field(default_factory=dict)
    issued_at: str = ""
    issuer_role: str = "ORCHESTRATOR"
    
    def to_yaml_dict(self) -> dict:
        return asdict(self)


@dataclass
class DocStewardResult:
    """DOC_STEWARD_RESULT packet per North-Star Operating Model v0.5"""
    packet_id: str
    packet_type: str = "DOC_STEWARD_RESULT"
    request_ref: str = ""
    case_id: str = ""
    status: str = ""  # SUCCESS | PARTIAL | FAILED | SKIPPED
    files_modified: list = field(default_factory=list)
    output_summary: str = ""
    verifier_outcome: str = ""
    evidence_ref: str = ""
    completed_at: str = ""
    
    def to_yaml_dict(self) -> dict:
        return asdict(self)


@dataclass
class VerifierOutcome:
    """Outcome from doc_verifier.py"""
    passed: bool
    findings: list = field(default_factory=list)
    summary: str = ""


# === Orchestrator Class ===
class DocStewardOrchestrator:
    """Thin orchestrator for DOC_STEWARD delegation."""
    
    def __init__(self, opencode_url: str = OPENCODE_URL, model: str = OPENCODE_MODEL):
        self.opencode_url = opencode_url
        self.model = model
        self.session_id: Optional[str] = None
    
    def create_request(self, mission_type: str, case_id: str, 
                       files: list = None, dry_run: bool = True) -> DocStewardRequest:
        """Create a DOC_STEWARD_REQUEST packet."""
        return DocStewardRequest(
            packet_id=f"req_{uuid.uuid4().hex[:12]}",
            case_id=case_id,
            mission_type=mission_type,
            files_to_steward=files or [],
            constraints={
                "dry_run": dry_run,
                "max_files": 10,
                "allowed_paths": ["docs/"],
                "forbidden_paths": ["docs/00_foundations/", "docs/01_governance/"]
            },
            issued_at=datetime.now(timezone.utc).isoformat()
        )
    
    def dispatch(self, request: DocStewardRequest) -> DocStewardResult:
        """Dispatch request to DOC_STEWARD (OpenCode) and get result."""
        
        # Build prompt for doc steward
        prompt = self._build_steward_prompt(request)
        
        # Check if dry_run - if so, simulate response
        if request.constraints.get("dry_run", True):
            return self._simulate_steward_response(request)
        
        # Real dispatch to OpenCode
        try:
            # Create session
            resp = requests.post(
                f"{self.opencode_url}/session",
                json={"title": f"DocSteward: {request.mission_type}", "model": self.model},
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            if resp.status_code != 200:
                return self._error_result(request, f"Session creation failed: {resp.text}")
            
            self.session_id = resp.json()["id"]
            
            # Send prompt
            resp = requests.post(
                f"{self.opencode_url}/session/{self.session_id}/message",
                json={"parts": [{"type": "text", "text": prompt}]},
                headers={"Content-Type": "application/json"},
                timeout=120
            )
            if resp.status_code != 200:
                return self._error_result(request, f"Prompt failed: {resp.text}")
            
            # Parse response
            return self._parse_steward_response(request, resp.json())
            
        except requests.exceptions.ConnectionError:
            return self._error_result(request, "OpenCode server unreachable")
        except Exception as e:
            return self._error_result(request, f"Dispatch error: {e}")
        finally:
            self._cleanup_session()
    
    def verify(self, result: DocStewardResult) -> VerifierOutcome:
        """Run doc_verifier on result."""
        try:
            from verifiers.doc_verifier import DocVerifier
            verifier = DocVerifier(docs_dir=DOCS_DIR)
            return verifier.verify(result)
        except ImportError:
            # Verifier not yet implemented - return pass for now
            return VerifierOutcome(
                passed=True,
                findings=[],
                summary="Verifier not yet implemented; assuming pass"
            )
    
    def emit_to_ledger(self, request: DocStewardRequest, result: DocStewardResult, 
                       outcome: VerifierOutcome, trial_type: str = "trial") -> str:
        """Emit request/result pair to DL_DOC ledger."""
        LEDGER_DIR.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y-%m-%d")
        filename = f"{timestamp}_{trial_type}_{request.case_id[:8]}.yaml"
        filepath = LEDGER_DIR / filename
        
        # Create stable YAML content
        entry = {
            "ledger": "DL_DOC",
            "entry_type": trial_type,
            "case_id": request.case_id,
            "recorded_at": datetime.now(timezone.utc).isoformat(),
            "request": request.to_yaml_dict(),
            "result": result.to_yaml_dict(),
            "verifier_outcome": {
                "passed": outcome.passed,
                "findings_count": len(outcome.findings),
                "summary": outcome.summary
            }
        }
        
        # Write as YAML (stable sorted format)
        import yaml
        with open(filepath, "w", encoding="utf-8") as f:
            yaml.dump(entry, f, default_flow_style=False, sort_keys=True, allow_unicode=True)
        
        return str(filepath)
    
    def run(self, mission_type: str, case_id: str = None, 
            dry_run: bool = True, trial_type: str = "trial") -> dict:
        """Execute full orchestration loop."""
        case_id = case_id or str(uuid.uuid4())
        
        print(f"[ORCHESTRATOR] Starting {mission_type} (case: {case_id[:8]}...)")
        print(f"[ORCHESTRATOR] Dry-run: {dry_run}")
        
        # 1. Create request
        request = self.create_request(mission_type, case_id, dry_run=dry_run)
        print(f"[ORCHESTRATOR] Request created: {request.packet_id}")
        
        # 2. Dispatch to DOC_STEWARD
        result = self.dispatch(request)
        print(f"[ORCHESTRATOR] Result received: {result.status}")
        
        # 3. Verify
        outcome = self.verify(result)
        result.verifier_outcome = "PASS" if outcome.passed else "FAIL"
        print(f"[ORCHESTRATOR] Verifier outcome: {result.verifier_outcome}")
        
        # 4. Emit to ledger
        ledger_path = self.emit_to_ledger(request, result, outcome, trial_type)
        result.evidence_ref = ledger_path
        print(f"[ORCHESTRATOR] Ledger entry: {ledger_path}")
        
        return {
            "success": outcome.passed and result.status in ("SUCCESS", "SKIPPED"),
            "case_id": case_id,
            "request_id": request.packet_id,
            "result_id": result.packet_id,
            "status": result.status,
            "verifier": result.verifier_outcome,
            "ledger_path": ledger_path
        }
    
    # === Private Methods ===
    
    def _build_steward_prompt(self, request: DocStewardRequest) -> str:
        """Build prompt for DOC_STEWARD role."""
        return f"""You are acting as DOC_STEWARD for LifeOS.

MISSION: {request.mission_type}
CASE_ID: {request.case_id}

CONSTRAINTS:
- Dry-run: {request.constraints.get('dry_run', True)}
- Max files: {request.constraints.get('max_files', 10)}
- Allowed paths: {request.constraints.get('allowed_paths')}
- Forbidden paths: {request.constraints.get('forbidden_paths')}

TASK:
1. If INDEX_UPDATE: Update timestamp in docs/INDEX.md
2. If CORPUS_REGEN: Regenerate docs/LifeOS_Strategic_Corpus.md
3. Report files modified and any issues found

Respond with a JSON object:
{{"status": "SUCCESS|PARTIAL|FAILED", "files_modified": [...], "summary": "..."}}
"""
    
    def _simulate_steward_response(self, request: DocStewardRequest) -> DocStewardResult:
        """Simulate DOC_STEWARD response for dry-run mode."""
        return DocStewardResult(
            packet_id=f"res_{uuid.uuid4().hex[:12]}",
            request_ref=request.packet_id,
            case_id=request.case_id,
            status="SKIPPED",  # In dry-run, we skip actual execution
            files_modified=[],
            output_summary=f"Dry-run simulation for {request.mission_type}",
            completed_at=datetime.now(timezone.utc).isoformat()
        )
    
    def _parse_steward_response(self, request: DocStewardRequest, response: dict) -> DocStewardResult:
        """Parse OpenCode response into DocStewardResult."""
        # Extract content from response
        try:
            content = response.get("content", "")
            # Try to parse JSON from response
            if "{" in content:
                json_start = content.index("{")
                json_end = content.rindex("}") + 1
                data = json.loads(content[json_start:json_end])
            else:
                data = {"status": "PARTIAL", "files_modified": [], "summary": content}
        except:
            data = {"status": "FAILED", "files_modified": [], "summary": "Failed to parse response"}
        
        return DocStewardResult(
            packet_id=f"res_{uuid.uuid4().hex[:12]}",
            request_ref=request.packet_id,
            case_id=request.case_id,
            status=data.get("status", "FAILED"),
            files_modified=data.get("files_modified", []),
            output_summary=data.get("summary", ""),
            completed_at=datetime.now(timezone.utc).isoformat()
        )
    
    def _error_result(self, request: DocStewardRequest, error_msg: str) -> DocStewardResult:
        """Create error result."""
        return DocStewardResult(
            packet_id=f"res_{uuid.uuid4().hex[:12]}",
            request_ref=request.packet_id,
            case_id=request.case_id,
            status="FAILED",
            files_modified=[],
            output_summary=f"ERROR: {error_msg}",
            completed_at=datetime.now(timezone.utc).isoformat()
        )
    
    def _cleanup_session(self):
        """Clean up OpenCode session."""
        if self.session_id:
            try:
                requests.delete(f"{self.opencode_url}/session/{self.session_id}")
            except:
                pass


# === CLI ===
def main():
    parser = argparse.ArgumentParser(description="Doc Steward Delegation Orchestrator")
    parser.add_argument("--mission", type=str, required=True, 
                        choices=["INDEX_UPDATE", "CORPUS_REGEN", "DOC_MOVE"],
                        help="Mission type to execute")
    parser.add_argument("--case-id", type=str, default=None,
                        help="Case ID (auto-generated if not provided)")
    parser.add_argument("--dry-run", action="store_true", default=True,
                        help="Dry-run mode (default: True)")
    parser.add_argument("--execute", action="store_true",
                        help="Actually execute (disables dry-run)")
    parser.add_argument("--trial-type", type=str, default="trial",
                        choices=["smoke_test", "shadow_trial", "trial"],
                        help="Trial type for ledger entry")
    
    args = parser.parse_args()
    
    dry_run = not args.execute
    
    orchestrator = DocStewardOrchestrator()
    result = orchestrator.run(
        mission_type=args.mission,
        case_id=args.case_id,
        dry_run=dry_run,
        trial_type=args.trial_type
    )
    
    print("\n" + "=" * 50)
    print(f"RESULT: {'PASS' if result['success'] else 'FAIL'}")
    print(f"Case ID: {result['case_id']}")
    print(f"Status: {result['status']}")
    print(f"Verifier: {result['verifier']}")
    print(f"Ledger: {result['ledger_path']}")
    print("=" * 50)
    
    sys.exit(0 if result["success"] else 1)


if __name__ == "__main__":
    main()
