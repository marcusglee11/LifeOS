#!/usr/bin/env python3
"""
Doc Verifier
============

Semantic validation for doc stewardship results.
Checks INDEX hygiene, link integrity, and other invariants.

Usage:
    from verifiers.doc_verifier import DocVerifier
    verifier = DocVerifier()
    outcome = verifier.verify(result)
"""

import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import List, Optional


@dataclass
class Finding:
    """A verification finding."""
    severity: str  # ERROR | WARNING | INFO
    category: str  # INDEX_HYGIENE | LINK_INTEGRITY | TIMESTAMP
    message: str
    location: str = ""


@dataclass
class VerifierOutcome:
    """Outcome from verification."""
    passed: bool
    findings: List[Finding] = field(default_factory=list)
    summary: str = ""
    
    @property
    def error_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "ERROR")
    
    @property
    def warning_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "WARNING")


class DocVerifier:
    """Semantic verifier for doc stewardship."""
    
    def __init__(self, docs_dir: Path = None):
        self.docs_dir = docs_dir or Path(__file__).parent.parent.parent / "docs"
    
    def verify(self, result=None) -> VerifierOutcome:
        """Run all verification checks and return outcome."""
        findings = []
        
        # Run all checks
        findings.extend(self.check_index_hygiene())
        findings.extend(self.check_timestamp_freshness())
        findings.extend(self.check_root_cleanliness())
        
        # Determine pass/fail
        error_count = sum(1 for f in findings if f.severity == "ERROR")
        warning_count = sum(1 for f in findings if f.severity == "WARNING")
        
        passed = error_count == 0
        summary = f"{error_count} errors, {warning_count} warnings"
        
        return VerifierOutcome(
            passed=passed,
            findings=findings,
            summary=summary
        )
    
    def check_index_hygiene(self) -> List[Finding]:
        """Check docs/INDEX.md for hygiene issues."""
        findings = []
        index_path = self.docs_dir / "INDEX.md"
        
        if not index_path.exists():
            findings.append(Finding(
                severity="ERROR",
                category="INDEX_HYGIENE",
                message="INDEX.md not found",
                location=str(index_path)
            ))
            return findings
        
        content = index_path.read_text(encoding="utf-8")
        
        # Check for Last Updated timestamp
        if "Last Updated" not in content and "last updated" not in content.lower():
            findings.append(Finding(
                severity="WARNING",
                category="INDEX_HYGIENE",
                message="INDEX.md missing 'Last Updated' timestamp",
                location=str(index_path)
            ))
        
        # Check for basic structure
        if "##" not in content:
            findings.append(Finding(
                severity="WARNING",
                category="INDEX_HYGIENE",
                message="INDEX.md may be missing section headers",
                location=str(index_path)
            ))
        
        # Check for broken internal links
        link_pattern = r'\[([^\]]+)\]\(([^)]+)\)'
        for match in re.finditer(link_pattern, content):
            link_text, link_target = match.groups()
            if link_target.startswith("file://"):
                # Absolute file link - check if exists
                target_path = link_target.replace("file:///", "").replace("file://", "")
                if not Path(target_path).exists():
                    findings.append(Finding(
                        severity="WARNING",
                        category="LINK_INTEGRITY",
                        message=f"Broken link: {link_text} -> {link_target}",
                        location=str(index_path)
                    ))
            elif not link_target.startswith("http"):
                # Relative link - check if exists
                target_path = self.docs_dir / link_target
                if not target_path.exists() and "#" not in link_target:
                    findings.append(Finding(
                        severity="WARNING",
                        category="LINK_INTEGRITY",
                        message=f"Broken relative link: {link_text} -> {link_target}",
                        location=str(index_path)
                    ))
        
        return findings
    
    def check_timestamp_freshness(self) -> List[Finding]:
        """Check if INDEX.md timestamp is reasonably fresh."""
        findings = []
        index_path = self.docs_dir / "INDEX.md"
        
        if not index_path.exists():
            return findings
        
        content = index_path.read_text(encoding="utf-8")
        
        # Look for timestamp patterns
        date_patterns = [
            r'Last Updated[:\s]+(\d{4}-\d{2}-\d{2})',
            r'\*\*Last Updated\*\*[:\s]+(\d{4}-\d{2}-\d{2})',
        ]
        
        for pattern in date_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                try:
                    timestamp = datetime.strptime(match.group(1), "%Y-%m-%d")
                    days_old = (datetime.now() - timestamp).days
                    if days_old > 30:
                        findings.append(Finding(
                            severity="INFO",
                            category="TIMESTAMP",
                            message=f"INDEX.md timestamp is {days_old} days old",
                            location=str(index_path)
                        ))
                except ValueError:
                    pass
                break
        
        return findings
    
    def check_root_cleanliness(self) -> List[Finding]:
        """Check that docs/ root only contains allowed files."""
        findings = []
        
        # Allowed at docs/ root
        allowed_root_files = {
            "INDEX.md",
            "LifeOS_Universal_Corpus.md",
            "LifeOS_Strategic_Corpus.md",
            ".obsidian"  # Obsidian config is okay
        }
        
        for item in self.docs_dir.iterdir():
            if item.is_file() and item.name not in allowed_root_files:
                findings.append(Finding(
                    severity="WARNING",
                    category="INDEX_HYGIENE",
                    message=f"Stray file at docs/ root: {item.name}",
                    location=str(item)
                ))
        
        return findings


# === CLI for standalone testing ===
def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Doc Verifier")
    parser.add_argument("--docs-dir", type=str, default=None,
                        help="Path to docs directory")
    parser.add_argument("--json", action="store_true",
                        help="Output as JSON")
    
    args = parser.parse_args()
    
    docs_dir = Path(args.docs_dir) if args.docs_dir else None
    verifier = DocVerifier(docs_dir=docs_dir)
    outcome = verifier.verify()
    
    if args.json:
        import json
        print(json.dumps({
            "passed": outcome.passed,
            "summary": outcome.summary,
            "findings": [
                {"severity": f.severity, "category": f.category, 
                 "message": f.message, "location": f.location}
                for f in outcome.findings
            ]
        }, indent=2))
    else:
        print(f"VERIFIER OUTCOME: {'PASS' if outcome.passed else 'FAIL'}")
        print(f"Summary: {outcome.summary}")
        for f in outcome.findings:
            print(f"  [{f.severity}] {f.category}: {f.message}")
    
    return 0 if outcome.passed else 1


if __name__ == "__main__":
    exit(main())
